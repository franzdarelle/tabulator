<?php 
class LOADER {
	public function load($folders=array()){
		foreach($folders as $folder){
			if ($handle = opendir(SITE_ROOT . '/app/' . $folder . '/')) {
				while (false !== ($file = readdir($handle))) {
					if ($file != "." && $file != "..") {
					   include $folder . "/" . $file;
					}
				}
				closedir($handle);
			} else
				exit("Can't load ".$folder);
		}
	}
}