<?php
class CRITERIAS extends ACCESS {
	public $eid, $message;
	private $table;
	public function __construct() { 
		parent::Connect();
		$this->table = array(
			'c' => DB_KEYWORD . '_criteria',
			'e' => DB_KEYWORD . '_event'
		); 
		$this->message = 'CRITERIAS';
	}
	public function setEID($eid){ 
		$this->eid = $eid; 
		return $this;
	}
	public function getEID(){ return $this->eid; }
	public function get($f='c'){
		if(in_array($f, array_keys($this->table)))
			return $this->PDO->query("SELECT * FROM ".$this->table[$f]);
		else{
			return $this->PDO->query("SELECT ".$this->table['c'].".*, ".$this->table['e'].".name as event FROM ".$this->table['c'].", ".$this->table['e']." WHERE ".$this->table['e'].".id=".$this->table['c'].".eid AND ".$this->table['c'].".eid=".$this->getEID());
		}
	}
	public function add($criteria, $percentage){
		try {
			$max = $this->max();
			$this->PDO->query("INSERT INTO ".$this->table['c']." (criteria, percentage, eid) VALUES ('".$this->Clean($criteria)."', ".(($percentage>$max)? $max:$percentage).",'".$this->getEID()."')");
		} catch (PDOException $e) {
			exit("add(): " . $e->getMessage());
		}
		return $this;
	}
	public function ups($criteria, $percentage, $id){
		try {
			$q = $this->row($id);
			if($q['percentage']==$percentage) $percent = $percentage;
			else {
				$m = (100 - $this->max()) - $q['percentage'];	
				$p = 100 - $m;	
				$percent = ($percentage > $p)? $p : $percentage;
			}
			$this->PDO->query("UPDATE ".$this->table['c']." SET criteria='".$this->Clean($criteria)."', percentage=".$percent." WHERE id=".$id);
		} catch (PDOException $e) {
			exit("ups(): " . $e->getMessage());
		}
		return $this;
	}
	public function max(){
		$q = $this->PDO->query("SELECT SUM(percentage) as p FROM ".$this->table['c']." WHERE eid=".$this->getEID());
		$r = $q->fetch(PDO::FETCH_ASSOC);
		return 100 - $r['p'];
	}
	public function row($id){
		$q = $this->PDO->query("SELECT * FROM ".$this->table['c']." WHERE id=".$id);
		$r = $q->fetch(PDO::FETCH_ASSOC);
		return $r;
	}
	public function del($id){
		$id = $this->Clean($id);
		if(is_numeric($id)){
			try {
				$this->PDO->query("DELETE FROM ".$this->table['c']." WHERE id=".$id);
			} catch (PDOException $e) {
				exit("del(): " . $e->getMessage());
			}
		}
		return $this;
	}
	public function set($id, $status=0){
		try {
			$this->PDO->query("UPDATE ".$this->table['c']." SET status=".$status." WHERE id=".$id);
		} catch (PDOException $e) {
			exit("set(): " . $e->getMessage());
		}
	}
}
