<?php
class EVENTS extends ACCESS {
	public $message;
	private $table;
	public function __construct() { 
		parent::Connect();
		$this->table = DB_KEYWORD . '_event'; 
		$this->message = 'EVENTS';
	}
	public function get(){
		return $this->PDO->query("SELECT * FROM ".$this->table);
	}
	public function add($name, $description, $venue){
		try {
			$this->PDO->query("INSERT INTO ".$this->table." (name, description, venue) VALUES ('".$this->Clean($name)."','".$this->Clean($description)."','".$this->Clean($venue)."')");
		} catch (PDOException $e) {
			exit("add(): " . $e->getMessage());
		}
		return $this;
	}
	public function del($id){
		$id = $this->Clean($id);
		if(is_numeric($id)){
			try {
				$this->PDO->query("DELETE FROM ".$this->table." WHERE id=".$id);
			} catch (PDOException $e) {
				exit("del(): " . $e->getMessage());
			}
		}
		return $this;
	}
	public function ups($name, $description, $venue, $id){
		try {
			$this->PDO->query("UPDATE ".$this->table." SET name='".$this->Clean($name)."', description='".$this->Clean($description)."', venue='".$this->Clean($venue)."' WHERE id=".$id);
		} catch (PDOException $e) {
			exit("ups(): " . $e->getMessage());
		}
		return $this;
	}
	public function set($id, $status=0){
		try {
			$this->PDO->query("UPDATE ".$this->table." SET status=".$status." WHERE id=".$id);
		} catch (PDOException $e) {
			exit("set(): " . $e->getMessage());
		}
		return $this;
	}
	public function row($id){
		$q = $this->PDO->query("SELECT * FROM ".$this->table." WHERE id=".$id);
		$r = $q->fetch(PDO::FETCH_ASSOC);
		return $r;
	}
}
