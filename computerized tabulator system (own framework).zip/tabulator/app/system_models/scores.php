<?php
class SCORES extends ACCESS {
	public $message;
	private $table;
	public function __construct() { 
		parent::Connect();
		$this->table = DB_KEYWORD . '_score'; 
		$this->message = 'SCORES';
	}
	public function all(){
		return $this->PDO->query("SELECT * FROM ".$this->table);
	}
	public function set($score, $criteria, $contestant, $uid){
		if($this->chk($criteria, $contestant, $uid)) $this->ups($score, $criteria, $contestant, $uid);
		else $this->add($score, $criteria, $contestant, $uid);
		return $this;
	}
	public function add($score, $criteria, $contestant, $uid){
		try {
			$this->PDO->query("INSERT INTO ".$this->table." (score, criteria, contestant, uid) VALUES ('".$this->Clean($score)."','".$this->Clean($criteria)."','".$this->Clean($contestant)."','".$uid."')");
		} catch (PDOException $e) {
			exit("add(): " . $e->getMessage());
		}
		return $this;
	}
	public function ups($score, $criteria, $contestant, $uid){
		try {
			$this->PDO->query("UPDATE ".$this->table." SET score=".$this->Clean($score)." WHERE criteria=".$criteria." AND contestant=".$contestant." AND uid=".$uid);
		} catch (PDOException $e) {
			exit("ups(): " . $e->getMessage());
		}
		return $this;
	}
	public function chk($criteria, $contestant, $uid){
		$q = $this->PDO->query("SELECT score FROM ".$this->table." WHERE criteria=".$criteria." AND contestant=".$contestant." AND uid=".$uid);
		$r = $q->fetch(PDO::FETCH_ASSOC);
		return (empty($r['score']))? false : true;
	}
	public function get($criteria, $contestant, $uid){
		try {
			$q = $this->PDO->query("SELECT * FROM ".$this->table." WHERE criteria=".$criteria." AND contestant=".$contestant." AND uid=".$uid);
			$r = $q->fetch(PDO::FETCH_ASSOC);
		} catch (PDOException $e) {
			$r = array('score'=>0, 'error'=>$e);
		}
		return $r;
	}
    public function row($criteria){
		try {
			$q = $this->PDO->query("SELECT * FROM ".$this->table." WHERE criteria=".$criteria);
			$r = $q->rowCount();
		} catch (PDOException $e) {
			$r = 0;
		}
		return $r;
	}
	public function del($id, $f=0){
		$id = $this->Clean($id);
		if(is_numeric($id)){
			switch($f){
				case 1:
					$field = 'uid';
				break;
				case 2:
					$field = 'contestant';
				break;
				case 3:
					$field = 'criteria';
				break;
				default:
					$field = 'id';
				break;
			}
			try {
				$this->PDO->query("DELETE FROM ".$this->table." WHERE ".$field."=".$id);
			} catch (PDOException $e) {
				exit("del(): " . $e->getMessage());
			}
		}
		return $this;
	}
	public function rem($criteria){
		try {
			$this->del($criteria, 3);
		} catch (PDOException $e) {
			exit("rem(): " . $e->getMessage());
		}
		return $this;
	}
}
