<?php
class CONTESTANTS extends ACCESS {
	public $message;
	private $table;
	public function __construct() { 
		parent::Connect();
		$this->table = array(
			'c' => DB_KEYWORD . '_contestant',
			'e' => DB_KEYWORD . '_event' 
		);
		$this->message = 'CONTESTANTS';
	}
	public function get($f='c'){
		if(in_array($f, array_keys($this->table)))
			return $this->PDO->query("SELECT * FROM ".$this->table[$f]);
		else
			return $this->PDO->query("SELECT ".$this->table['c'].".*, ".$this->table['e'].".name as event FROM ".$this->table['c'].", ".$this->table['e']." WHERE ".$this->table['e'].".id=".$this->table['c'].".eid");
	}
	public function add($numb, $name, $addr, $file, $evnt){
		try {
			$this->PDO->query("INSERT INTO ".$this->table['c']." (number, name, address, photo, eid) VALUES ('".$this->Clean($numb)."','".$this->Clean($name)."','".$this->Clean($addr)."','".$this->Clean($file)."','".$this->Clean($evnt)."')");
		} catch (PDOException $e) {
			exit("add(): " . $e->getMessage());
		}
		return $this;
	}
	public function ups($numb, $name, $addr, $file, $evnt, $id){
		try {
			$this->PDO->query("UPDATE ".$this->table['c']." SET number = '".$this->Clean($numb)."', name = '".$this->Clean($name)."', address = '".$this->Clean($addr)."', photo = '".$this->Clean($file)."', eid = '".$this->Clean($evnt)."' WHERE id=".$id);
		} catch (PDOException $e) {
			exit("ups(): " . $e->getMessage());
		}
		return $this;
	}
	public function del($id){
		$id = $this->Clean($id);
		if(is_numeric($id)){
			try {
				$this->PDO->query("DELETE FROM ".$this->table['c']." WHERE id=".$id);
			} catch (PDOException $e) {
				exit("del(): " . $e->getMessage());
			}
		}
		return $this;
	}
	public function row($id){
		$q = $this->PDO->query("SELECT * FROM ".$this->table['c']." WHERE id=".$id);
		$r = $q->fetch(PDO::FETCH_ASSOC);
		return $r;
	}
	public function eid($eid, $act=null, $eli=null){
		$s = "SELECT * FROM ".$this->table['c']." WHERE eid=".$eid;
		if(!is_null($act)) $s .= " AND status=".$act;
		if(!is_null($eli)) $s .= " AND eliminate=".$eli;
		$s .= " ORDER BY number";
		return $this->PDO->query($s);
	}
	public function set($id, $status=0){
		try {
			$this->PDO->query("UPDATE ".$this->table['c']." SET status=".$status." WHERE id=".$id);
		} catch (PDOException $e) {
			exit("set(): " . $e->getMessage());
		}
		return $this;
	}
	public function sec($id, $eliminate=0){
		try {
			$this->PDO->query("UPDATE ".$this->table['c']." SET eliminate=".$eliminate." WHERE id=".$id);
		} catch (PDOException $e) {
			exit("sec(): " . $e->getMessage());
		}
		return $this;
	}
}
