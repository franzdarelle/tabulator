<?php
class USERS extends ACCESS {
	public $session, $message;
	private $table, $pagination, $shadow = 'shw/';
	public function __construct(){
		parent::Connect()->Keyword();
		$this->session = new SESSIONS;
		$this->table = array(
			'user' => DB_KEYWORD . '_user',
			'salt' => DB_KEYWORD . '_salt'
		);
		$this->message = 'USERS';
	}
	public function mkeShadow($file, $content){
		chmod($this->shadow, 0777);
		$fp = fopen($this->shadow.$file, 'w+') or die("mkeShadow()");
		if($fp){
			fwrite($fp, $content);
			fclose($fp);
		}
		chmod($this->shadow, 0600);
		return $this;
	}
	public function getShadow($id){
		$q = $this->PDO->query("SELECT * FROM ".$this->table['salt']." WHERE id = '$id'");
		$r = $q->fetch(PDO::FETCH_ASSOC);
		return $r['prefix'].$r['suffix'];
	}
	public function getContent($file){
		chmod($this->shadow, 0777);
		$content = trim(file_get_contents($this->shadow.$file));
		chmod($this->shadow, 0600);
		return $content;
	}
	public function remShadow($file){
		chmod($this->shadow, 0777);
		unlink($this->shadow.$file);
		chmod($this->shadow, 0600);
		return $this;
	}
	public function signin($name, $pass){
		$q = $this->PDO->query("SELECT * FROM " .$this->table['user']. "," .$this->table['salt']." WHERE _user = '" .$this->Clean($name). "' AND ".$this->table['user'].'.id = '.$this->table['salt'].".id"); 
		if($q->rowCount()>0){
			$pass = trim($pass);
			$data = $q->fetch(PDO::FETCH_ASSOC);
			$file = $data['prefix'].$data['suffix'].'.txt';
			$prefix = $data['prefix'];
			$suffix = $data['suffix'];
			$prefix = md5($prefix);
			$suffix = sha1($suffix);
			$rpword = sha1($pass);
			$rpword = md5($rpword);
			$rpword = base64_encode( $prefix.$rpword.$suffix );
			$rpword = md5($rpword);
			$rpword = sha1($rpword);
			$rpword = trim($rpword);
			$dbpass = trim($data['_pass']);
			if($rpword==$dbpass AND $pass==$this->getContent($file)){
				$this->session->setUid($data['id']);
				$this->session->setUser($data['_user']);
				$this->session->setType($data['_type']);
				$this->session->setPass($dbpass);
				$this->session->setTime(time());
				return true;
			}else
				return false;
		}else
			return false;
	}
	public function rename($name, $pass){
		$i = $this->session->getUid();
		$p = $this->getContent($this->getShadow($i).'.txt');
		if ($pass==$p) {
			try {
				$n = $this->Clean($name);
		        $q = $this->PDO->query("UPDATE ".$this->table['user']." SET _user = '".$n."' WHERE id=".$i);
		        $this->session->setUser($n);
		        return true;
		    } catch (PDOException $e) {
		        exit("rename(): " . $e->getMessage());
		    }
		}
		return "Invalid Password";
	}
	public function repass($opass, $npass, $cpass){
		$i = $this->session->getUid();
		$p = $this->getContent($this->getShadow($i).'.txt');
		if ($opass==$p) {
			if($npass==$cpass){
				try {
					$newpass = $this->Clean($npass);
					$prefix = random_string(SALT_LENGTH);
					$suffix = random_string(SALT_LENGTH);
					$newPrefix = $prefix;
					$newSuffix = $suffix;
					$prefix = md5($prefix);
					$suffix = sha1($suffix);
					$rpword = sha1($newpass);
					$rpword = md5($rpword);
					$rpword = base64_encode( $prefix.$rpword.$suffix );
					$rpword = md5($rpword);
					$rpword = sha1($rpword);
					$rpword = trim($rpword);
			        $q = $this->PDO->query("UPDATE ".$this->table['user']." SET _pass = '".$rpword."' WHERE id = '".$i."'");
			        $this->remShadow($this->getShadow($i).'.txt')->mkeShadow($newPrefix.$newSuffix.'.txt', $newpass);
			        $q = $this->PDO->query("UPDATE ".$this->table['salt']." SET prefix = '".$newPrefix."', suffix = '".$newSuffix."' WHERE id = '".$i."'");
			        $this->session->setPass($rpword);
			        return true;
			    } catch (PDOException $e) {
			        exit("rename(): " . $e->getMessage());
			    }
			} else return "Confirm New Password";
		} 
		return "Invalid Old Password";
	}
	public function create($name, $pass){
		$name = $this->Clean($name);
		$pass = $this->Clean($pass);
		$prefix = random_string(SALT_LENGTH);
		$suffix = random_string(SALT_LENGTH);
		$newPrefix = $prefix;
		$newSuffix = $suffix;
		$prefix = md5($prefix);
		$suffix = sha1($suffix);
		$rpword = sha1($pass);
		$rpword = md5($rpword);
		$rpword = base64_encode( $prefix.$rpword.$suffix );
		$rpword = md5($rpword);
		$rpword = sha1($rpword);
		$rpword = trim($rpword);
		$q = $this->PDO->query("INSERT INTO ".$this->table['user']." (_user, _pass) VALUES ('".$name."', '".$rpword."')");
		$u = $this->PDO->lastInsertId();
		$q = $this->PDO->query("INSERT INTO ".$this->table['salt']." (id, prefix, suffix) VALUES ('".$u."', '".$newPrefix."', '".$newSuffix."')");
		$this->mkeShadow($newPrefix.$newSuffix.'.txt', $pass);
		return $u;
	}
	public function remove($id){
		$this->remShadow($this->getShadow($id).'.txt')->delete($id);
		return $this;
	}
	public function delete($id){
		$id = $this->Clean($id);
		if(is_numeric($id)){
			try {
				$this->PDO->query("DELETE FROM ".$this->table['user']." WHERE id=".$id);
				$this->PDO->query("DELETE FROM ".$this->table['salt']." WHERE id=".$id);
			} catch (PDOException $e) {
				exit("delete(): " . $e->getMessage());
			}
		}
		return $this;
	}
	public function update($pass, $id){
		$mypass = $this->Clean($pass);
		$prefix = random_string(SALT_LENGTH);
		$suffix = random_string(SALT_LENGTH);
		$newPrefix = $prefix;
		$newSuffix = $suffix;
		$prefix = md5($prefix);
		$suffix = sha1($suffix);
		$rpword = sha1($mypass);
		$rpword = md5($rpword);
		$rpword = base64_encode( $prefix.$rpword.$suffix );
		$rpword = md5($rpword);
		$rpword = sha1($rpword);
		$rpword = trim($rpword);
        $q = $this->PDO->query("UPDATE ".$this->table['user']." SET _pass = '".$rpword."' WHERE id=".$id);
        $this->remShadow($this->getShadow($id).'.txt')->mkeShadow($newPrefix.$newSuffix.'.txt', $mypass);
        $q = $this->PDO->query("UPDATE ".$this->table['salt']." SET prefix = '".$newPrefix."', suffix = '".$newSuffix."' WHERE id=".$id);
		return $this;
	}
}
