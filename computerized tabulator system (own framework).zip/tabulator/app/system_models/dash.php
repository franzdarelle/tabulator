<?php
class DASH extends ACCESS {
	public $message, $ev, $cr, $co, $db, $sc, $us, $ju;
	private $table;
	public function __construct() { 
		parent::Connect();
		$this->table = DB_KEYWORD . '_dash';
		$this->message = 'DASH';
		$this->ev = new EVENTS;
	    $this->cr = new CRITERIAS;
	    $this->co = new CONTESTANTS;
		$this->ju = new JUDGES;
		$this->sc = new SCORES;
		$this->us = new SESSIONS;
		$this->db = $this->getDash();
		$this->co->set($this->db['contestant'], 1);
	}
	public function setDash($k, $v){
		$this->db[$k] = $v;
		return $this;
	}
	public function getDash(){
		$q = $this->PDO->query("SELECT * FROM ".$this->table);
		$r = $q->fetch(PDO::FETCH_ASSOC);
		return $r;
	}
	public function getEvents(){
		$r = array();
		$e = $this->ev->get();
		foreach($e as $k => $v){
			if($v['status']){
				if($this->cr->setEID($v['id'])->max()==100) continue;
				else {
					$i = 0;
					$c = $this->setDash('event', $v['id'])->getContestants();
					foreach($c as $d) $i++; 
					if($i > 0) $r[] = $v;
				}
			}
		}
		$this->db = $this->getDash();
		return $r;
	}
	public function getCriterias(){
		return $this->cr->setEID($this->db['event'])->get('x');
	}
	public function getContestants($act=null, $eli=null){
		return $this->co->eid($this->db['event'], $act, $eli);
	}
	public function getEliminated(){
		return $this->co->eid($this->db['event'], null, 1);
	}
    public function getJudges(){
		return $this->ju->jbe($this->db['event']);
    }
	public function getPhoto(){
		$p = $this->co->row($this->db['contestant']);
		return $p;
	}
	public function getEvent(){
		$e = $this->ev->row($this->db['event']);
		return $e;
	}
	public function getCriteria(){
		$c = $this->cr->row($this->db['criteria']);
		return $c;
	}
	public function ev($event){
		try {
			$this->PDO->query("UPDATE ".$this->table." SET event=".$this->Clean($event));
		} catch (PDOException $e) {
			exit("ev(): " . $e->getMessage());
		}
		return $this;
	}
	public function cr($criteria){
		try {
			foreach($this->getCriterias() as $c) $this->cr->set($c['id'], 0);
			$this->cr->set($criteria, 1);
			$this->PDO->query("UPDATE ".$this->table." SET criteria=".$this->Clean($criteria));
		} catch (PDOException $e) {
			exit("cr(): " . $e->getMessage());
		}
		return $this;
	}
	public function co($contestant){
		try {
			$this->PDO->query("UPDATE ".$this->table." SET contestant=".$this->Clean($contestant));
			$this->co->set($contestant, 1);
		} catch (PDOException $e) {
			exit("co(): " . $e->getMessage());
		}
		return $this;
	}
	public function ra(){
		try {
			$c = $this->co->eid($this->db['event'], 1);
			foreach($c as $i){
				$this->co->set($i['id'], 0);
			}
		} catch (PDOException $e) {
			exit("ra(): " . $e->getMessage());
		}
		return $this;
	}
	public function ac($contestant){
		try {
			$this->PDO->query("UPDATE ".$this->table." SET contestant=".$this->Clean($contestant));
		} catch (PDOException $e) {
			exit("ac(): " . $e->getMessage());
		}
		return $this;
	}
	public function ar($contestant){
		try {
			$this->co->set($contestant, 0);
		} catch (PDOException $e) {
			exit("ar(): " . $e->getMessage());
		}
		return $this;
	}
	public function ec($contestant){
		try {
			$this->co->sec($contestant, 1);
		} catch (PDOException $e) {
			exit("ec(): " . $e->getMessage());
		}
		return $this;
	}
	public function er($contestant){
		try {
			$this->co->sec($contestant, 0);
		} catch (PDOException $e) {
			exit("er(): " . $e->getMessage());
		}
		return $this;
	}
	public function re(){
		try {
			$c = $this->co->eid($this->db['event'], null, 1);
			foreach($c as $i){
				$this->co->sec($i['id'], 0);
			}
		} catch (PDOException $e) {
			exit("re(): " . $e->getMessage());
		}
		return $this;
	}
	public function rs(){
		try {
			foreach($this->getCriterias() as $c) $this->sc->rem($c['id']);
		} catch (PDOException $e) {
			exit("rs(): " . $e->getMessage());
		}
		return $this;
	}
	public function dump(){
		$dbhost = DB_HOST;
		$dbuser = DB_USER;
		$dbpass = DB_PASS;
		$dbname = DB_NAME;
		$dbfile = $dbname.'.sql';
		$dbpath = SITE_ROOT.'/web/'.$dbfile;
		$output = shell_exec("mysqldump --user=$dbuser --password='$dbpass' --host=$dbhost $dbname > $dbpath");
		return (file_exists($dbpath))? array('name'=>$dbfile,'path'=>$dbpath) : array('error'=>$output);
	}
	public function free($path){
		$files = array();
		if($handle = opendir($path)){
			while (false !== ($file = readdir($handle))) {
				if(!in_array($file, array(".", ".."))){ 
					$files[] = $file;
					unlink($path.$file);
				}
			}
			closedir($handle);
		}
		return array('files'=>$files, 'count'=>count($files));
	}
}
