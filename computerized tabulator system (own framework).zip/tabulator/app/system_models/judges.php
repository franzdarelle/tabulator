<?php
class JUDGES extends ACCESS {
	public $message;
	private $table;
	public function __construct() { 
		parent::Connect();
		$this->table = array(
			'j' => DB_KEYWORD . '_judge',
			'e' => DB_KEYWORD . '_event',
			'u' => DB_KEYWORD . '_user'  
		);
		$this->message = 'JUDGES';
	}
	public function get($f='j'){
		if(in_array($f, array_keys($this->table)))
			return $this->PDO->query("SELECT * FROM ".$this->table[$f]);
		else
			return $this->PDO->query("SELECT ".$this->table['j'].".*, ".$this->table['e'].".name as event, ".$this->table['u']."._user FROM ".$this->table['j'].", ".$this->table['e'].", ".$this->table['u']." WHERE ".$this->table['u'].".id=".$this->table['j'].".uid AND ".$this->table['e'].".id=".$this->table['j'].".eid");
	}
	public function add($n, $d, $e, $u){
		try {
			$this->PDO->query("INSERT INTO ".$this->table['j']." (name, description, eid, uid) VALUES ('".$this->Clean($n)."','".$this->Clean($d)."','".$e."','".$u."')");
		} catch (PDOException $e) {
			exit("add(): " . $e->getMessage());
		}
		return $this;
	}
	public function ups($n, $d, $e, $s, $u, $i){
		try {
			$this->PDO->query("UPDATE ".$this->table['j']." SET name = '".$this->Clean($n)."', description = '".$this->Clean($d)."', eid = '".$e."' WHERE id=".$i);
			$this->PDO->query("UPDATE ".$this->table['u']." SET _user = '".$this->Clean($s)."' WHERE id=".$u);
		} catch (PDOException $e) {
			exit("ups(): " . $e->getMessage());
		}
		return $this;
	}
	public function del($id){
		$id = $this->Clean($id);
		if(is_numeric($id)){
			try {
				$this->PDO->query("DELETE FROM ".$this->table['j']." WHERE id=".$id);
			} catch (PDOException $e) {
				exit("del(): " . $e->getMessage());
			}
		}
		return $this;
	}
	public function row($id){
		$q = $this->PDO->query("SELECT ".$this->table['j'].".*, ".$this->table['e'].".name as event, ".$this->table['u']."._user FROM ".$this->table['j'].", ".$this->table['e'].", ".$this->table['u']." WHERE ".$this->table['u'].".id=".$this->table['j'].".uid AND ".$this->table['e'].".id=".$this->table['j'].".eid AND ".$this->table['j'].".id=".$id);
		$r = $q->fetch(PDO::FETCH_ASSOC);
		return $r;
	}
	public function chk($uid){
		$q = $this->PDO->query("SELECT ".$this->table['e'].".status FROM ".$this->table['j'].", ".$this->table['e']." WHERE ".$this->table['e'].".id=".$this->table['j'].".eid AND ".$this->table['j'].".uid=".$uid);
		$r = $q->fetch(PDO::FETCH_ASSOC);
		return $r['status'];
	}
    public function eid($uid){
		if(empty($uid)) return $this;
		$q = $this->PDO->query("SELECT eid FROM ".$this->table['j']." WHERE uid=".$uid);
		$r = $q->fetch(PDO::FETCH_ASSOC);
		return $r['eid'];
	}
    public function jbe($eid){
		return $this->PDO->query("SELECT * FROM ".$this->table['j']." WHERE eid=".$eid);
	}
	public function log($uid, $log=0){
		try {
			$this->PDO->query("UPDATE ".$this->table['j']." SET log=".$log." WHERE uid=".$uid);
		} catch (PDOException $e) {
			exit("log(): " . $e->getMessage());
		}
		return $this;
	}
}
