<?php
class dashAJAX {
	public $post, $data, $dash, $show, $path;
	public function __construct($data) {
		$this->data = $data;
		$this->post = @$_POST['d'];
		$this->show = @$_POST['n'];
		$this->dash = new DASH;
		$this->path = 'xls/';
	}

	public function get_data(){
		return $this->data;
	}
	
	public function get_post(){
		return $this->post;
	}

	public function set_post($v){
		$this->post = $v;
		return $this;
	}

    public function get_show(){
		return $this->show;
	}

	public function set_show($v){
		$this->show = $v;
		return $this;
	}

	public function ev(){
		if($this->dash->ev($this->get_post())){
			if($this->get_show()==1) return 1; 
			else {
				$_SESSION[$this->dash->message] = 'Event successfully changed.';
				return 1;
			}
		}
	}

	public function cr(){
		if($this->dash->cr($this->get_post())){
			if($this->get_show()==1) return 1; 
			else {
				$_SESSION[$this->dash->message] = 'Criteria successfully changed.';
				return 1;
			}
		}
	}
	
	public function co(){
		if($this->dash->co($this->get_post())){
			if($this->get_show()==1) return 1;
			else {
				$_SESSION[$this->dash->message] = 'Contestant successfully changed.';
				return 1;
			}
		}
	}

	public function ra(){
		if($this->dash->ra($this->get_post())){
			$_SESSION[$this->dash->message] = 'Contestants successfully deactivated.';
			return 1;
		}
	}

	public function ac(){
		if($this->dash->ac($this->get_post())){
			$_SESSION[$this->dash->message] = 'Contestant successfully activated.';
			return 1;
		}
	}

	public function ar(){
		if($this->dash->ar($this->get_post())){
			$_SESSION[$this->dash->message] = 'Contestant successfully deactivated.';
			return 1;
		}
	}

	public function ec(){
		if($this->dash->ec($this->get_post())){
			$_SESSION[$this->dash->message] = 'Contestant successfully eliminated.';
			return 1;
		}
	}

	public function er(){
		if($this->dash->er($this->get_post())){
			$_SESSION[$this->dash->message] = 'Contestant successfully removed.';
			return 1;
		}
	}

	public function re(){
		if($this->dash->re($this->get_post())){
			$_SESSION[$this->dash->message] = 'Contestants successfully removed.';
			return 1;
		}
	}

	public function gd(){
		return json_encode($this->dash->getDash());
    }

    public function gp(){
		if($this->get_post()){
			return json_encode($this->dash->setDash('contestant', $this->get_post())->getPhoto());
		} 
		return json_encode($this->dash->getPhoto());
    }
	
	public function ge(){
		return json_encode($this->dash->getEvent());
    }

	public function gc(){
		$d = array();
		foreach($this->dash->getCriterias() as $k => $v){ 
			$s = $this->dash->sc->get($v['id'], (($this->get_post())? $this->get_post() : $this->dash->db['contestant']), $this->dash->us->getUid());
			$v['score'] = $s['score'];
			$d[] = $v;
		}
		return json_encode($d);
	}

	public function sc(){
		$c = 0;
		foreach($this->get_post() as $d){
			if(empty($d['val'])) continue;
			if($this->dash->sc->set($d['val'], $d['cid'], (($this->get_show())? $this->get_show() : $this->dash->db['contestant']), $this->dash->us->getUid())) $c++;
		}
		if($c){
			$_SESSION[$this->dash->message] = (($c>1)? 'Scores' : 'Score') .' successfully saved.';
			return 1;
		} else 
			return 'Error saving score...';
	}

    public function jv(){
		$d = array();
		foreach($this->dash->getJudges() as $k => $v){
			$v['score'] = $this->dash->sc->chk($this->dash->db['criteria'], $this->dash->db['contestant'], $v['uid']);
			$d[] = $v;
		}
		return json_encode($d);
	}

	public function rs(){
		if($this->get_post()){
			if($this->dash->rs()){
				$_SESSION[$this->dash->message] = 'Scores successfully reset.';
				return 1;
			}
		}
	}
	
	public function cl(){
		if($this->get_post()){
			$d = $v = $r = array();
			foreach($this->dash->getContestants() as $k){ 
				if($k['eliminate']==0){
					$cid = $k['id'];
					$judges = $score = $jscore = 0;
					foreach($this->dash->getJudges() as $j){
						$sum = 0;
						$uid = $j['uid'];
						foreach($this->dash->getCriterias() as $c){ 
							$q = $this->dash->sc->get($c['id'], $cid, $uid);
							$sum += ($q['score'] * $c['percentage']) / 100;
						}	
						$jscore += $sum;	
						$judges++;
					}
					$score = $jscore / $judges;
					$d[] = array(
						'id' => $cid,
						'number' => $k['number'],
						'name' => $k['name'],
						'status' => $k['status'],
						'score' => $score			
					);
				}
			}
			foreach($d as $key => $val) $v[$key] = $val['score'];
			arsort($v);
			foreach($v as $key => $val) $r[] = $d[$key];
			return json_encode($r);
		}
	}

    public function jr(){
		if($this->get_post()){
			$d = $v = $r = array();
			foreach($this->dash->getContestants() as $k){ 
				if($k['eliminate']==0){
					$c = $this->dash->getCriteria();
					$s = $this->dash->sc->get($c['id'], $k['id'], $this->dash->us->getUid());
					$d[] = array(
						'id' => $k['id'],
						'number' => $k['number'],
						'name' => $k['name'],
						'status' => $k['status'],
						'score' => $s['score']			
					);
				}
			}
			foreach($d as $key => $val) $v[$key] = $val['score'];
			arsort($v);
			foreach($v as $key => $val) $r[] = $d[$key];
			return json_encode($r);
		}
	}

	public function pb(){
		if($this->get_post()){
			$p = 0;
			$i = array();
			foreach($this->dash->getCriterias() as $c){ 
				$s = $this->dash->sc->row($c['id']);
				if($s){
					$i[]= $c['criteria'];
					$p += $c['percentage'];
				} 
			}
			return json_encode(array('progress'=>$p,'criteria'=>implode(', ', $i)));
		}
	}

	public function sb(){
		if($this->get_post()){
			$d = array();
			foreach($this->dash->getCriterias() as $c) 
			$d[] = array(
				'percentage' => $c['percentage'], 'criteria' => $c['criteria'],
				'class' => ($c['id']==$this->dash->db['criteria'])? "bar bar-danger" : (($this->dash->sc->row($c['id']))? "bar bar-success" : "bar bar-info")
			);
			return json_encode($d);
		}
	}

	public function vr(){
		if($this->set_post(1)->get_post()){
			$d = $v = $r = array();
			foreach($this->dash->getContestants() as $k){ 
				if($k['eliminate']==0){
					$judges = $score = $jscore = 0;
					foreach($this->dash->getJudges() as $j){
						$c = $this->dash->getCriteria();
						$q = $this->dash->sc->get($c['id'], $k['id'], $j['uid']);
						$jscore += ($this->get_show())? $q['score'] : (($q['score'] * $c['percentage']) / 100);	
						$judges++;
					}
					$score = $jscore / $judges;
					$d[] = array(
						'id' => $k['id'],
						'number' => $k['number'],
						'name' => $k['name'],
						'status' => $k['status'],
						'score' => $score			
					);
				}
			}
			foreach($d as $key => $val) $v[$key] = $val['score'];
			arsort($v);
			foreach($v as $key => $val) $r[] = $d[$key];
			return json_encode($r);
		}
	}
	
	public function prc(){
		if($this->get_post()){
			include_once SITE_ROOT . '/app/PHPExcel/PHPExcel.php';
			$fields = array(
				0 =>'A',
				1 =>'B',
				2 =>'C',
				3 =>'D',
				4 =>'E',
				5 =>'F',
				6 =>'G',
				7 =>'H',
				8 =>'I',
				9 =>'J',
				10=>'K',
				11=>'L',
				12=>'M',
				13=>'N',
				14=>'O',
				15=>'P',
				16=>'Q',
				17=>'R',
				18=>'S',
				19=>'T',
				20=>'U',
				21=>'V',
				22=>'W',
				23=>'X',
				24=>'Y',
				25=>'Z'
			);
			$style = array(
				'head' => array(
					'font' => array('bold' => true,),
					'alignment' => array('horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER, 'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER),
					'borders' => array('allborders' => array('style' => PHPExcel_Style_Border::BORDER_THIN,),),
					'fill' => array('type' => PHPExcel_Style_Fill::FILL_SOLID, 'startcolor' => array('argb' => 'FFAABBFF',)),
				),
				'data' => array(
					'borders' => array('allborders' => array('style' => PHPExcel_Style_Border::BORDER_THIN,),),
					'alignment' => array('vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER)
				),
				'name' => array(
					'font' => array('bold' => true,),
					'alignment' => array('horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER, 'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER),
				) 
			);		
			set_time_limit(0);
			ini_set("memory_limit", -1);
			$e = $this->dash->getEvent();
			$c = $this->dash->getCriteria();
			$d = $this->set_show(1)->vr();
			$r = objectToArray(json_decode($d));
			$creator = ucwords($this->dash->us->getUser());
			$cid = $c['id'];
			$event = $e['name'];
			$criteria = $c['criteria'];
			$percentage = $c['percentage'];
			$currentRow = $judges = $i = 1;
			$objPHPExcel = new PHPExcel();
			$objPHPExcel->getProperties()->setCreator($creator)
										 ->setLastModifiedBy($creator)
										 ->setTitle($criteria)
										 ->setSubject($criteria)
										 ->setDescription($criteria)
										 ->setKeywords($criteria)
										 ->setCategory($criteria);							 
			//$objPHPExcel->getActiveSheet()->getHeaderFooter()->setOddHeader($event);
			foreach($this->dash->getJudges() as $j) $judges++;
			$objPHPExcel->getActiveSheet()->getColumnDimension($fields[0])->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension($fields[1])->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension($fields[2])->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension($fields[3])->setWidth(30);
			$objPHPExcel->getActiveSheet()->mergeCells($fields[0].$currentRow.':'.$fields[3 + ($judges-1)].$currentRow);
			$objPHPExcel->getActiveSheet()->getRowDimension($currentRow)->setRowHeight(30);
			$objPHPExcel->getActiveSheet()->getStyle($fields[0].$currentRow)->applyFromArray($style['name'])->getAlignment()->setWrapText(true);	 
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue($fields[0].$currentRow, $event.' - '.$criteria.' ('.$percentage.'%)');
			$currentRow++;
			$objPHPExcel->getActiveSheet()->getRowDimension($currentRow)->setRowHeight(25);
			$objPHPExcel->getActiveSheet()->getStyle($fields[0].$currentRow.':'.$fields[3].$currentRow)->applyFromArray($style['head'])->getAlignment()->setWrapText(true);
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue($fields[0].$currentRow, 'Rank');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue($fields[1].$currentRow, 'Score');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue($fields[2].$currentRow, 'Number');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue($fields[3].$currentRow, 'Contestant');
			$judges = 4;
			foreach($this->dash->getJudges() as $j){
				$objPHPExcel->getActiveSheet()->getColumnDimension($fields[$judges])->setWidth(30);
				$objPHPExcel->getActiveSheet()->setCellValue($fields[$judges].$currentRow, $j['name']);
				$judges++;
			}
			if($judges > 4){
				$objPHPExcel->getActiveSheet()->getStyle($fields[4].$currentRow.':'.$fields[$judges-1].$currentRow)->applyFromArray($style['head'])->getAlignment()->setWrapText(true);
				$judges -= 4;
			}
			$field = $judges;
			$currentRow++;
			foreach($r as $c){
				$objPHPExcel->setActiveSheetIndex(0)->setCellValue($fields[0].$currentRow, $i);
				$objPHPExcel->setActiveSheetIndex(0)->setCellValue($fields[1].$currentRow, '=AVERAGE('.$fields[4].$currentRow.':'.$fields[3 + $field].$currentRow.')');
				$objPHPExcel->getActiveSheet()->getStyle($fields[1].$currentRow)->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_NUMBER_00);
				$objPHPExcel->setActiveSheetIndex(0)->setCellValue($fields[2].$currentRow, $c['number']);
				$objPHPExcel->setActiveSheetIndex(0)->setCellValue($fields[3].$currentRow, utf8_encode($c['name']));
				$objPHPExcel->getActiveSheet()->getRowDimension($currentRow)->setRowHeight(20);
				$objPHPExcel->getActiveSheet()->getStyle($fields[0].$currentRow.':'.$fields[3].$currentRow)->applyFromArray($style['data'])->getAlignment()->setWrapText(true);
				$judges = 4;
				foreach($this->dash->getJudges() as $j){
					$q = $this->dash->sc->get($cid, $c['id'], $j['uid']);
					$objPHPExcel->getActiveSheet()->setCellValue($fields[$judges].$currentRow, number_format($q['score'], 2));
					$judges++;
				}
				if($judges > 4){
					$objPHPExcel->getActiveSheet()->getStyle($fields[4].$currentRow.':'.$fields[$judges-1].$currentRow)->applyFromArray($style['data'])->getAlignment()->setWrapText(true);
				}	
				$currentRow++;
				$i++;
			}
			$file = $criteria . ".xlsx";
			$objPHPExcel->getActiveSheet()->setTitle($criteria);
			$objPHPExcel->setActiveSheetIndex(0);	
			$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
			$objWriter->save($this->path.$file);
			$objPHPExcel->disconnectWorksheets();
			unset($objPHPExcel);
			return json_encode(array('file'=>$file, 'path'=>BASEURL.$this->path));
		}
	}
	public function pre(){
		if($this->get_post()){
			include_once SITE_ROOT . '/app/PHPExcel/PHPExcel.php';
			$fields = array(
				0 =>'A',
				1 =>'B',
				2 =>'C',
				3 =>'D',
				4 =>'E',
				5 =>'F',
				6 =>'G',
				7 =>'H',
				8 =>'I',
				9 =>'J',
				10=>'K',
				11=>'L',
				12=>'M',
				13=>'N',
				14=>'O',
				15=>'P',
				16=>'Q',
				17=>'R',
				18=>'S',
				19=>'T',
				20=>'U',
				21=>'V',
				22=>'W',
				23=>'X',
				24=>'Y',
				25=>'Z'
			);
			$style = array(
				'head' => array(
					'font' => array('bold' => true,),
					'alignment' => array('horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER, 'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER),
					'borders' => array('allborders' => array('style' => PHPExcel_Style_Border::BORDER_THIN,),),
					'fill' => array('type' => PHPExcel_Style_Fill::FILL_SOLID, 'startcolor' => array('argb' => 'FFAABBFF',)),
				),
				'data' => array(
					'borders' => array('allborders' => array('style' => PHPExcel_Style_Border::BORDER_THIN,),),
					'alignment' => array('vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER)
				),
				'name' => array(
					'font' => array('bold' => true,),
					'alignment' => array('horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER, 'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER),
				) 
			);		
			set_time_limit(0);
			ini_set("memory_limit", -1);
			$e = $this->dash->getEvent();
			$d = $this->set_show(1)->cl();
			$r = objectToArray(json_decode($d));
			$event = $e['name'];
			$creator = ucwords($this->dash->us->getUser());
			$currentRow = $sheet = $i = 1;
			$objPHPExcel = new PHPExcel();
			$objPHPExcel->getProperties()->setCreator($creator)
										 ->setLastModifiedBy($creator)
										 ->setTitle($event)
										 ->setSubject($event)
										 ->setDescription($event)
										 ->setKeywords($event)
										 ->setCategory($event);							 
			//$objPHPExcel->getActiveSheet()->getHeaderFooter()->setOddHeader($event);
			$judges = 1;
			foreach($this->dash->getJudges() as $j) $judges++;
			$objPHPExcel->getActiveSheet()->getColumnDimension($fields[0])->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension($fields[1])->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension($fields[2])->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension($fields[3])->setWidth(30);
			$objPHPExcel->getActiveSheet()->mergeCells($fields[0].$currentRow.':'.$fields[3 + ($judges-1)].$currentRow);
			$objPHPExcel->getActiveSheet()->getRowDimension($currentRow)->setRowHeight(30);
			$objPHPExcel->getActiveSheet()->getStyle($fields[0].$currentRow)->applyFromArray($style['name'])->getAlignment()->setWrapText(true);	 
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue($fields[0].$currentRow, $event);
			$currentRow++;
			$objPHPExcel->getActiveSheet()->getRowDimension($currentRow)->setRowHeight(25);
			$objPHPExcel->getActiveSheet()->getStyle($fields[0].$currentRow.':'.$fields[3].$currentRow)->applyFromArray($style['head'])->getAlignment()->setWrapText(true);
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue($fields[0].$currentRow, 'Rank');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue($fields[1].$currentRow, 'Score');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue($fields[2].$currentRow, 'Number');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue($fields[3].$currentRow, 'Contestant');
			$judges = 4;
			foreach($this->dash->getJudges() as $j){
				$objPHPExcel->getActiveSheet()->getColumnDimension($fields[$judges])->setWidth(30);
				$objPHPExcel->setActiveSheetIndex(0)->setCellValue($fields[$judges].$currentRow, $j['name']);
				$judges++;
			}
			if($judges > 4){
				$objPHPExcel->getActiveSheet()->getStyle($fields[4].$currentRow.':'.$fields[$judges-1].$currentRow)->applyFromArray($style['head'])->getAlignment()->setWrapText(true);
				$judges -= 4;
			}
			$field = $judges;
			$currentRow++;
			foreach($r as $c){
				$objPHPExcel->setActiveSheetIndex(0)->setCellValue($fields[0].$currentRow, $i);
				$objPHPExcel->setActiveSheetIndex(0)->setCellValue($fields[1].$currentRow, '=AVERAGE('.$fields[4].$currentRow.':'.$fields[3 + $field].$currentRow.')');
				$objPHPExcel->getActiveSheet()->getStyle($fields[1].$currentRow)->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_NUMBER_00);
				$objPHPExcel->setActiveSheetIndex(0)->setCellValue($fields[2].$currentRow, $c['number']);
				$objPHPExcel->setActiveSheetIndex(0)->setCellValue($fields[3].$currentRow, utf8_encode($c['name']));
				$objPHPExcel->getActiveSheet()->getRowDimension($currentRow)->setRowHeight(20);
				$objPHPExcel->getActiveSheet()->getStyle($fields[0].$currentRow.':'.$fields[3].$currentRow)->applyFromArray($style['data'])->getAlignment()->setWrapText(true);	
				$judges = 4;
				foreach($this->dash->getJudges() as $j){
					$s = 0;
					foreach($this->dash->getCriterias() as $k){ 
						$q = $this->dash->sc->get($k['id'], $c['id'], $j['uid']);
						$s += ($q['score'] * $k['percentage']) / 100;
					}
					$objPHPExcel->setActiveSheetIndex(0)->setCellValue($fields[$judges].$currentRow, number_format($s, 2));
					$judges++;
				}
				if($judges > 4){
					$objPHPExcel->getActiveSheet()->getStyle($fields[4].$currentRow.':'.$fields[$judges-1].$currentRow)->applyFromArray($style['data'])->getAlignment()->setWrapText(true);
				}
				$currentRow++;
				$i++;
			}
			$file = $event . ".xlsx";
			$objPHPExcel->getActiveSheet()->setTitle($event);
			foreach($this->dash->getCriterias() as $c){ 
				$objPHPExcel->createSheet($sheet);
				$objPHPExcel->getSheet($sheet)->setTitle($c['criteria']);
				$objPHPExcel->setActiveSheetIndex($sheet);
				$currentRow = $judges = 1;
				foreach($this->dash->getJudges() as $j) $judges++;
				$objPHPExcel->getActiveSheet()->getColumnDimension($fields[0])->setWidth(10);
				$objPHPExcel->getActiveSheet()->getColumnDimension($fields[1])->setWidth(10);
				$objPHPExcel->getActiveSheet()->getColumnDimension($fields[2])->setWidth(10);
				$objPHPExcel->getActiveSheet()->getColumnDimension($fields[3])->setWidth(30);
				$objPHPExcel->getActiveSheet()->mergeCells($fields[0].$currentRow.':'.$fields[3 + ($judges-1)].$currentRow);
				$objPHPExcel->getActiveSheet()->getRowDimension($currentRow)->setRowHeight(30);
				$objPHPExcel->getActiveSheet()->getStyle($fields[0].$currentRow)->applyFromArray($style['name'])->getAlignment()->setWrapText(true);	 
				$objPHPExcel->getActiveSheet()->setCellValue($fields[0].$currentRow, $c['criteria'].' - '.$c['percentage'].'%');
				$currentRow++;
				$objPHPExcel->getActiveSheet()->getRowDimension($currentRow)->setRowHeight(25);
				$objPHPExcel->getActiveSheet()->getStyle($fields[0].$currentRow.':'.$fields[3].$currentRow)->applyFromArray($style['head'])->getAlignment()->setWrapText(true);
				$objPHPExcel->getActiveSheet()->setCellValue($fields[0].$currentRow, 'Rank');
				$objPHPExcel->getActiveSheet()->setCellValue($fields[1].$currentRow, 'Score');
				$objPHPExcel->getActiveSheet()->setCellValue($fields[2].$currentRow, 'Number');
				$objPHPExcel->getActiveSheet()->setCellValue($fields[3].$currentRow, 'Contestant');
				$judges = 4;
				foreach($this->dash->getJudges() as $j){
					$objPHPExcel->getActiveSheet()->getColumnDimension($fields[$judges])->setWidth(30);
					$objPHPExcel->getActiveSheet()->setCellValue($fields[$judges].$currentRow, $j['name']);
					$judges++;
				}
				if($judges > 4){
					$objPHPExcel->getActiveSheet()->getStyle($fields[4].$currentRow.':'.$fields[$judges-1].$currentRow)->applyFromArray($style['head'])->getAlignment()->setWrapText(true);
					$judges -= 4;
				}
				$field = $judges;
				$currentRow++;
				$i = 1;
				$d = $this->vr();
				$r = objectToArray(json_decode($d));
				foreach($r as $x){
					$objPHPExcel->getActiveSheet()->setCellValue($fields[0].$currentRow, $i);
					$objPHPExcel->getActiveSheet()->setCellValue($fields[1].$currentRow, '=AVERAGE('.$fields[4].$currentRow.':'.$fields[3 + $field].$currentRow.')');
					$objPHPExcel->getActiveSheet()->getStyle($fields[1].$currentRow)->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_NUMBER_00);
					$objPHPExcel->getActiveSheet()->setCellValue($fields[2].$currentRow, $x['number']);
					$objPHPExcel->getActiveSheet()->setCellValue($fields[3].$currentRow, utf8_encode($x['name']));
					$objPHPExcel->getActiveSheet()->getRowDimension($currentRow)->setRowHeight(20);
					$objPHPExcel->getActiveSheet()->getStyle($fields[0].$currentRow.':'.$fields[3].$currentRow)->applyFromArray($style['data'])->getAlignment()->setWrapText(true);	
					$judges = 4;
					foreach($this->dash->getJudges() as $j){
						$q = $this->dash->sc->get($c['id'], $x['id'], $j['uid']);
						$objPHPExcel->getActiveSheet()->setCellValue($fields[$judges].$currentRow, number_format($q['score'], 2));
						$judges++;
					}
					if($judges > 4){
						$objPHPExcel->getActiveSheet()->getStyle($fields[4].$currentRow.':'.$fields[$judges-1].$currentRow)->applyFromArray($style['data'])->getAlignment()->setWrapText(true);
					}
					$currentRow++;
					$i++;
				}
				$sheet++;
			}
			$objPHPExcel->setActiveSheetIndex(0);
			$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
			$objWriter->save($this->path.$file);
			$objPHPExcel->disconnectWorksheets();
			unset($objPHPExcel);
			return json_encode(array('file'=>$file, 'path'=>BASEURL.$this->path));
		}
	}
	public function backupDB(){
		return json_encode($this->dash->dump());
	}
	public function clearXLS(){
		if($this->dash->us->getType()) return json_encode($this->dash->free($this->path));
	}
	public function clearIMG(){
		if($this->dash->us->getType()){
			$contestantAJAX = new contestantAJAX;
			return json_encode($contestantAJAX->rem());
		}
	}
}


