<?php
class contestantAJAX {
	public $post, $data, $cont, $exts, $path, $file;
	public function __construct($data) {
		$this->data = $data;
		$this->post = @$_POST['d'];
		$this->cont = new CONTESTANTS;
		$this->exts = array("jpg", "png", "gif", "bmp", "jpeg", "pdf");
		$this->path = 'upl/';
		$this->file = IMG_UPLOAD;
	}

	public function get_data(){
		return $this->data;
	}
	
	public function get_post(){
		return $this->post;
	}

	public function set_post($post){
		$this->post = $post;
		return $this;
	}

	public function upl(){
		$out = $tmp = $ext = null;
		foreach ($_FILES['photos']['name'] as $name => $value){
			$tmp = $_FILES['photos']['tmp_name'][$name];
	        $ext = strtolower(pathinfo($_FILES['photos']['name'][$name], PATHINFO_EXTENSION));
	        if(in_array($ext, $this->exts)) {
		       	if(filesize($tmp) < (MAX_UPLOAD*1024)) {
	    			$image = random_string(20) . '.' . $ext;
	                if (move_uploaded_file($tmp, $this->path.$image)) {
	            		$_SESSION[$this->file] = $image;
	            		$out .= "<img src='".BASEURL.$this->path.$image."' class='img'>";
	        	    } else $out .= 'You have exceeded the size limit!';
	            } else $out .= 'You have exceeded the size limit!';
	        } else $out .= 'Unknown extension!';
	    }
	    return $out;
	}

	public function add(){
		$d = $this->get_data();
		$r = $this->cont->add($d['numb'], $d['name'], $d['addr'], ((isset($_SESSION[$this->file]))? $_SESSION[$this->file] : ''), $d['evnt']);
		if($r){
			$_SESSION[$this->cont->message] = 'Contestant successfully added.';
			if(isset($_SESSION[$this->file])){ 
				Image::resizeImage($this->path.$_SESSION[$this->file], IMG_SIZE_W, IMG_SIZE_H, $this->path.$_SESSION[$this->file]);
				unset($_SESSION[$this->file]);
			}
			return 1;
		} else 
			return 'Error adding...';
	}

	public function ups(){
		$d = $this->get_data();
		$p = $this->cont->row($d['id']);
		$r = $this->cont->ups($d['number'], $d['name'], $d['address'], ((isset($_SESSION[$this->file]))? $_SESSION[$this->file] : $p['photo']), $d['event'], $d['id']);
		if($r){
			$_SESSION[$this->cont->message] = 'Contestant successfully edited.';
			if(isset($_SESSION[$this->file])){
				Image::resizeImage($this->path.$_SESSION[$this->file], IMG_SIZE_W, IMG_SIZE_H, $this->path.$_SESSION[$this->file]); 
				unset($_SESSION[$this->file]);
			}
			return 1;
		} else 
			return 'Error editing...';
	}

	public function del(){
		$s = new SCORES;
		$c = 0;
		foreach ($this->get_post() as $d){
			if($this->cont->del($d)){ 
				$s->del($d, 2);			
				$c++;
			}
		}
		if($c>0){
			$_SESSION[$this->cont->message] = (($c==1)? 'Contestant' : ($c .' Contestants')) . ' successfully deleted.';
			return 1;
		} else
			return 'Error deleting...';
	}

	public function rem(){
		$files = array();
		if($handle = opendir($this->path)){
			$i = array();
			$c = $this->cont->get();
			foreach ($c as $d) $i[] = $d['photo'];
			while (false !== ($file = readdir($handle))) {
				if (!in_array($file, array(".", ".."))) {
					if(!in_array($file, $i)){
						$files[] = $file;
						unlink($this->path.$file);
					}  
				}
			}
			closedir($handle);
		}
		return array('files'=>$files, 'count'=>count($files));
	}

	public function get(){
		$d = $this->get_post();
		return json_encode($this->cont->row($d));
	}

	public function clr(){
		if(isset($_SESSION[$this->cont->message])) unset($_SESSION[$this->cont->message]);
		return $this;
	}

	public function reset(){
		if(isset($_SESSION[$this->file])) unset($_SESSION[$this->file]);
		return true;
	}
}


