<?php
class criteriaAJAX {
	public $post, $data, $crit;
	public function __construct($data) {
		$this->data = $data;
		$this->post = @$_POST['d'];
		$this->crit = new CRITERIAS;
	}

	public function get_data(){
		return $this->data;
	}
	
	public function get_post(){
		return $this->post;
	}

	public function set_post($post){
		$this->post = $post;
		return $this;
	}

	public function add(){
		$d = $this->get_data();
		$r = $this->crit->setEID($d['e'])->add($d['c'], $d['p']);
		if($r){
			$_SESSION[$this->crit->message] = 'Criteria successfully added.';
			return 1;
		} else 
			return 'Error adding...';
	}

	public function ups(){
		$d = $this->get_data();
		$r = $this->crit->setEID($d['eid'])->ups($d['criteria'], $d['percentage'], $d['id']);
		if($r){
			$_SESSION[$this->crit->message] = 'Criteria successfully edited.';
			return 1;
		} else 
			return 'Error editing...';
	}

	public function del(){
		$s = new SCORES;
		$c = 0;
		foreach ($this->get_post() as $d){
			if($this->crit->del($d)){ 
				$s->rem($d);
				$c++;
			}
		}
		if($c>0){
			$e = ($c==1)? 'Criteria' : ($c .' Criterias');
			$_SESSION[$this->crit->message] = $e . ' successfully deleted.';
			return 1;
		} else
			return 'Error deleting...';
	}

	public function get(){
		$d = $this->get_post();
		return json_encode($this->crit->row($d));
	}

	public function clr(){
		if(isset($_SESSION[$this->crit->message])) unset($_SESSION[$this->crit->message]);
		return $this;
	}
}


