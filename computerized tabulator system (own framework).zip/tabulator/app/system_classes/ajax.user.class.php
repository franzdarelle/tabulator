<?php
class userAJAX {
	public $post, $user, $data, $salt;
	public function __construct($data) {
		$this->data = $data;
		$this->post = @$_POST['d'];
		$this->user	= new USERS;
		$this->salt	= 10;
	}

	public function get_request(){
		return $this->data;
	}
	
	public function get_post(){
		return $this->post;
	}
	
	public function get_invalid(){
		return "Invalid username and/or password!";
	}

	public function signin(){
		$d = $this->get_request();
		$i = $this->get_invalid();
		if(isset($d['token']) AND ($d['token']==$_SESSION['token'])){
			return ($this->user->signin($d[$_SESSION['field']['name']], $d[$_SESSION['field']['pass']]))? 1 : $i;
		}
		return $i;
	}

	public function changeusr(){
		$d = $this->get_request();
		$r = $this->user->rename($d['uname'], $d['upass']);
		if($r===true){
			$_SESSION[$this->user->message] = 'Username successfully changed.';
			return 1;
		}
		return $r;
	}

	public function changepwd(){
		$d = $this->get_request();
		$r = $this->user->repass($d['opass'], $d['npass'], $d['cpass']);
		if($r===true){
			$_SESSION[$this->user->message] = 'Password successfully changed.';
			return 1;
		}
		return $r;
	}
}


