<?php
define('TRASH_DATA', 0);
class Query {

	#db Connection
	private $connection;

	#db HostName
	private $hostname = DB_HOST;

	#db UserName
	private $username = DB_USER;

	#db Password
	private $password = DB_PASS;

	#db Name
	private $database = DB_NAME;

	#SQL
	public $sql = "";
	
	#tells if where clause is already used in SQL
	private $where = false;

	public $query;

	#db Table
	public $table;

	#Query variable
	public $result;

	#Error String
	public $error = "";
	
	#mysql_insert_id();
	public $insert_id;

	public function __construct() {
		$this->connect();
		$this->updateKeywords();
	}

	#db Update Table Keyword
	private function updateKeywords(){
		$tables = $this->query('SHOW tables')->fetchAssoc();
		foreach($tables as $tbl){
			$tbl_name = $tbl['Tables_in_'.$this->database];
			$tbl_keys = explode('_', $tbl_name);
			$tbl_new_name = str_replace($tbl_keys[0], DB_KEYWORD, $tbl_name);
			if($tbl_name==$tbl_new_name) return $this;
			$this->query('RENAME TABLE ' . $tbl_name . ' TO ' . $tbl_new_name);
		}
		return $this;
	}
	
	#db Connection
	public function connect() {
		$this->connection = mysql_connect($this->hostname, $this->username, $this->password);
		mysql_select_db($this->database, $this->connection);
		return $this;
	}

	#db Disconnection
	public function disconnect() {
		mysql_close();
		return $this;
	}

	#db Select Database (Optional)
	public function db_select($dbname=null) {
		if(!is_null($dbname)) {
			mysql_select_db($dbname, $this->connection);
		} else {
			$this->error .= "Database name is not define, call to a Query class member function db_select.";
			$this->show_error();
			exit;
		}
		return $this;
	}
	
	public function db_return() {
		mysql_select_db($this->database, $this->connection);
		return $this;
	}

	#db Query Execution
	public function query($sql=null) {
		if(is_null($sql)) {
			$this->error = "query must have a string parameter";
			$this->show_error();
		} else {
			if(TRASH_DATA==1) $this->isdelete($sql);
			$this->result = mysql_query($sql);
			if(mysql_error()) {
				$this->error = mysql_error();
				$this->show_error();
			}
		}
		return $this;
	}
	
	private function isdelete($sql) {
		$delete = strpos($sql, 'DELETE');
		if($delete !== false) {
			$new_sql = str_replace("DELETE FROM", "SELECT * FROM", $sql);
			$qry 	 = mysql_query($new_sql);
			$records = array();
			if(mysql_num_rows($qry)>0) {
				while($row = mysql_fetch_assoc($qry)) {
					$records[] = $row;
				}
				$sqlcreateTable = "CREATE TABLE IF NOT EXISTS trash (id BIGINT PRIMARY KEY AUTO_INCREMENT, user CHAR(50), data TEXT, stamp INT(11))";
				mysql_query($sqlcreateTable);
				$sqlInsertTable = "INSERT INTO trash (data, user, stamp) VALUES ('".addslashes(serialize($records))."', '".$_SESSION[WEB_SESSION]['uid']."', '".time()."')";
				return mysql_query($sqlInsertTable);	
			}else
				return false;
		}else
			return false;
	}

	#db Count Rows Resource#
	public function count() {
		if(!is_resource($this->result)) {
			print '<span class="fce"><b>Invalid Query</b> result. Can\'t count() the number of rows. <em>Query must be <b>resource</b></em>.</span>';
			return false;
		} else
			return mysql_num_rows($this->result);
	}

	public function fetchAssoc() {
	
		$resultSet = array();
		while($row = mysql_fetch_assoc($this->result)) {
			$resultSet[] = $row;
		}
		return $resultSet;
	}
	
	public function query_result($row=0, $field="") {
		return mysql_result($this->result, $row, $field);
	}
	
	public function getAffected() {
		return mysql_affected_rows();
	}

	public function getResult() {
		return $this->result;
	}

	public function setTable($tablename=null) {
	
		if(!is_null($tablename)) {
			$this->table = is_array($tablename)? implode(",",$tablename) : $tablename;
		} else {
			$this->error .= "Call to a member function setTable, table name is not define.";
			$this->show_error();
		}
		return $this;
	}

	public function select($fields="") {
	
		if(is_array($fields)) {
			$selected_fields = implode(",", $fields);
		} else {
			$selected_fields = ($fields=="")? "*" : $fields;
		}
	
		$this->sql = "SELECT $selected_fields FROM " . $this->table . " ";
	
		return $this;
	}

	public function where($where=null) {
	
		if(is_null($where)) {
			return $this;
		} else {
			if(is_array($where) AND count($where)>=1 ) {
				$this->sql .= ($this->where)? "AND " : "WHERE ";
				$this->where = true;
				$key = false;
				foreach($where as $field=>$value) {
					$value = (is_numeric($value))? $value : '"' . $this->escape($value) . '"';
					$this->sql .= $key ? "AND " : "";
					$this->sql .= $field . " LIKE " . $value . " ";
					$key=true;
				}
			}
		}
		return $this;
	}

	public function whereEqual($where=null) {
	
		if(is_null($where)) {
			return $this;
		} else {
			if(is_array($where) AND count($where)>=1 ) {
				$this->sql .= ($this->where)? "AND " : "WHERE ";
				$this->where = true;
				$andSQL = false;
				foreach($where as $field=>$value) {
					$this->sql .= $andSQL ? "AND " : "";
					$this->sql .= $field . "=" . $value . " ";
					$andSQL=true;
				}
			}
		}
		return $this;
	}
	
	public function whereIn($items=null) {
		
		if(is_null($items)) {
			return $this;
		} else {
			if(is_array($items) AND count($items)>=1) {
				$this->sql .= ($this->where)? "AND " : "WHERE ";
				$this->where = true;
				$andSQL = false;
				foreach($items as $field=>$value) {
					if(is_array($value)) {
						$tempVals = array();
						foreach($value as $val) {
							$tempVals[] = is_numeric($val)? $val : '"' . $this->escape($val) . '"';
						}
						$value = implode(",", $tempVals);
					}
					$this->sql .= $andSQL ? "AND " : "";
					$this->sql .= $field . " IN (" . $value . ") ";
					$andSQL = true;
				}
			}
		}
		return $this;
	}
	
	public function whereNotIn($items=null) {

		if(is_null($items)) {
			return $this;
		} else {
			if(is_array($items) AND count($items)>=1) {
				$this->sql .= ($this->where)? 'AND ' : 'WHERE ';
				$this->where = true;
				foreach($items as $field=>$value) {
					if(is_array($value)) {
						$tempVals = array();
						foreach($value as $val) {
							$tempVals[] = is_numeric($val)? $val : '"' . $this->escape($val) . '"';
						}
						$value = implode(',', $tempVals);
					}
					$this->sql .= $field . ' NOT IN (' . $value . ') ';
					$andSQL = true;
				}
			}
		}
		return $this;
	}

	public function group($fields) {
		
		if(is_array($fields)) {
			$this->sql .= count($fields)? "GROUP BY " . implode(', ', $fields) . " " : "";
		} else {
			$this->sql .= ($fields<>'')? "GROUP BY " . $fields . " " : "";
		}
		
		return $this;
	}

	public function order($fields) {
	
		if(is_array($fields)) {
			$this->sql .= count($fields)? "ORDER BY " . implode(', ', $fields) . " " : "";
		} else {
			$this->sql .= ($fields<>'')? "ORDER BY " . $fields . " " : "";
		}
		return $this;
	}

	public function limit($offset, $display=null) {

		if(is_null($display)) {
			$this->sql .= "LIMIT $offset ";
		} else {
			$this->sql .= "LIMIT $offset, $display ";
		}
		return $this;
	}

	public function insert($values=array(), $tablename=null) {
	
		array_walk($values, create_function('&$val', '$val=trim($val);'));
		if(!is_array($values)) {
			$this->error .= "Parameter to a member function insert must be an array.";
		} elseif(count($values)==1) {
			$this->error .= "Insert values to a member function insert is empty.";
		} else {
			$table = (is_null($tablename))? $this->table : $tablename;
			if(empty($table)) {
				$this->error = "Table is not set.";
				$this->show_error();
			} else {
				$field = array();
				$value = array();
				foreach($values as $key=>$val) {
					$field[] = $key;
					$value[] = '"' . $this->escape($val) . '"';
				}
			
				$sql = "INSERT INTO " . $table . " (" . implode(",", $field) . ") VALUES (" . implode(",", $value) . ")";
				$this->query($sql);
			}
		}
		$this->insert_id = mysql_insert_id();
		$this->show_error();
		return $this;
	}
	
	public function update($values=array(), $tablename=null) {
	
		$this->reset();
		array_walk($values, create_function('&$val', '$val=trim($val);'));
		if(!is_array($values)) {
			$this->error .= "Parameter to a member function update must be an array.";
		} elseif(count($values)<1) {
			$this->error .= "Update values to a member function update is empty.";
		} else {
			$table = (is_null($tablename))? $this->table : $tablename;
			if(empty($table)) {
				$this->error = "Table is not set.";
				$this->show_error();
			} else {
				$setItems = array();
				foreach($values as $key=>$val) {
					$field = $key;
					$value = (is_numeric($val))? $val : $this->escape($val);
					$setItems[] = $field . "='" . $value . "'"; 
				}

				$this->sql = "UPDATE " . $table . " SET " . implode(",", $setItems) . " ";
			}
		}
	
		$this->show_error();
		return $this;
	}

	public function delete() {
		$this->sql = "DELETE FROM " . $this->table . " ";
		return $this;
	}

	public function exec() {
		$this->result = $this->query($this->sql)->getResult();
		$this->query = $this->result;
		return $this;
	}
	
	public function reset() {
		$this->sql = '';
		$this->where = false;
		return $this;
	}

	public function escape($string) {
	
		$string = get_magic_quotes_gpc()? stripslashes($string) : $string;
		$string = mysql_real_escape_string($string);
		return $string;
	}

	public function show_error() {
	
		if($this->error != "") {
			print $this->error;
			exit;
		} else {
			return;
		}
	}
	
	public function get_last_id(){
		return $this->insert_id;
	}
}

#DB QUERY
function db_query($sql) {
	$qry = new Query;
	return $qry->query($sql);
}






