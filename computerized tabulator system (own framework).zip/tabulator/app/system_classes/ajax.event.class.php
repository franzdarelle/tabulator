<?php
class eventAJAX {
	public $post, $data, $evnt, $juds, $crit, $cont, $dash;
	public function __construct($data) {
		$this->data = $data;
		$this->post = @$_POST['d'];
		$this->dash = new DASH;
		$this->evnt = new EVENTS;
		$this->juds = new JUDGES;
		$this->crit = new CRITERIAS;
		$this->cont = new CONTESTANTS;
	}

	public function get_data(){
		return $this->data;
	}
	
	public function get_post(){
		return $this->post;
	}

	public function addEvent(){
		$d = $this->get_data();
		$r = $this->evnt->add($d['name'], $d['desc'], $d['venu']);
		if($r){
			$_SESSION[$this->evnt->message] = 'Event successfully added.';
			return 1;
		} else 
			return 'Error adding...';
	}

	public function upsEvent(){
		$d = $this->get_data();
		$r = $this->evnt->ups($d['name'], $d['description'], $d['venue'], $d['id']);
		if($r){
			$_SESSION[$this->evnt->message] = 'Event successfully edited.';
			return 1;
		} else 
			return 'Error editing...';
	}

	public function actEvent(){
		$c = 0;
		foreach ($this->get_post() as $d){
			if($this->evnt->set($d, 1)) $c++;
		}
		if($c>0){
			$e = ($c==1)? 'Event' : ($c .' Events');
			$_SESSION[$this->evnt->message] = $e . ' successfully activated.';
			return 1;
		} else
			return 'Error activating...';
	}

	public function deaEvent(){
		$c = 0;
		foreach ($this->get_post() as $d){
			if($this->evnt->set($d, 0)) $c++;
		}
		if($c>0){
			$e = ($c==1)? 'Event' : ($c .' Events');
			$_SESSION[$this->evnt->message] = $e . ' successfully deactivated.';
			return 1;
		} else
			return 'Error deactivating...';
	}

	public function delEvent(){
		$c = 0;
		foreach ($this->get_post() as $d){
			if($d==$this->dash->db['event']) continue;
			if($this->sanitize($d)->evnt->del($d)) $c++;
		}
		if($c>0){
			$e = ($c==1)? 'Event' : ($c .' Events');
			$_SESSION[$this->evnt->message] = $e . ' successfully deleted.';
			return 1;
		} else
			return 'Error deleting...';
	}

	public function getEvent(){
		$d = $this->get_post();
		return json_encode($this->evnt->row($d));
	}

	public function sanitize($eid){
		return $this->delJudges($eid)->delContestants($eid)->delCriterias($eid);
	}

	public function delJudges($eid){
		$d = array();
		foreach($this->juds->jbe($eid) as $v) $d[] = $v['id'];
		$judgeAJAX = new judgeAJAX;
		$judgeAJAX->set_post($d)->del();
		$judgeAJAX->clr();
		return $this;
	}

	public function delCriterias($eid){
		$d = array();
		foreach($this->crit->setEID($eid)->get('x') as $v) $d[] = $v['id'];
		$criteriaAJAX = new criteriaAJAX;
		$criteriaAJAX->set_post($d)->del();
		$criteriaAJAX->clr();
		return $this;
	}

	public function delContestants($eid){
		$d = array();
		foreach($this->cont->eid($eid) as $v) $d[] = $v['id'];
		$contestantAJAX = new contestantAJAX;
		$contestantAJAX->set_post($d)->del();
		$contestantAJAX->clr();
		return $this;
	}
}


