<?php
class ACCESS {
	var $PDO, $dbHost, $dbUser, $dbPass, $dbName;
	function __construct() {
    	$this->Connect();
	}
	public function Connect(){
	    $this->dbHost = DB_HOST;
	    $this->dbUser = DB_USER;
		$this->dbPass = DB_PASS;
	    $this->dbName = DB_NAME;
	    try {
	    	$this->PDO = new PDO('mysql:host='.$this->dbHost.';dbname='.$this->dbName, $this->dbUser, $this->dbPass, array(PDO::ATTR_PERSISTENT => true));
			return $this;
		} catch (PDOException $e) {
			exit("Connect(): " . $e->getMessage());
		}
	}
	public function Close(){
		$this->PDO = null;
	}
	public function Clean($string) {
		$string = get_magic_quotes_gpc()? stripslashes($string) : $string;
		$string = addslashes($string);
		return $string;
	}
	public function Keyword(){
		$tables = $this->PDO->query("SHOW tables");
		foreach($tables as $tbl){
			$name = $tbl['Tables_in_'.$this->dbName];
			$part = explode('_', $name);
			if($part[0]==DB_KEYWORD) continue;
			else $this->PDO->query('RENAME TABLE '.$name.' TO '.str_replace($part[0], DB_KEYWORD, $name));
		}
		return $this;
	}
}
