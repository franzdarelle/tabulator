<?php
class SESSIONS {

	public $uid, $user, $pass, $type, $time;
	private $webSession = WEB_SESSION;

	public function __construct() {
		if($this->isLogged()){
			$this->uid 	= (empty($_SESSION[$this->webSession]['uid']))  ? false : $_SESSION[$this->webSession]['uid'];
			$this->user = (empty($_SESSION[$this->webSession]['user'])) ? false : $_SESSION[$this->webSession]['user'];
			$this->pass = (empty($_SESSION[$this->webSession]['pass'])) ? false : $_SESSION[$this->webSession]['pass'];
			$this->type = (empty($_SESSION[$this->webSession]['type'])) ? false : $_SESSION[$this->webSession]['type'];
			$this->time = (empty($_SESSION[$this->webSession]['time'])) ? false : time();
		}
	}	

	#SET UID
	public function setUid($uid=null) {
		if(!is_null($uid)) {
			$this->uid = $uid;
			$_SESSION[$this->webSession]['uid'] = $uid;
		}else
			$this->uid = false;
		return $this;
	}
	
	#GET UID
	public function getUid() {
		return $this->uid;
	}

	#SET USER
	public function setUser($user=null){
		if(!is_null($user)) {
			$this->user = $user;
			$_SESSION[$this->webSession]['user'] = $this->user;
		}else 
			$this->user = false;
		return $this;
	}
	
	#GET USER
	public function getUser(){
		return $this->user;
	}
	
	#SET PASS
	public function setPass($pass=null){
		if(!is_null($pass)) {
			$this->pass = $pass;
			$_SESSION[$this->webSession]['pass'] = $this->pass;
		}else 
			$this->pass = false;
		return $this;
	}
	
	#GET PASS
	public function getPass(){
		return $this->pass;
	}
	
	#SET TYPE
	public function setType($type=null){
		if(!is_null($type)) {
			$this->type = $type;
			$_SESSION[$this->webSession]['type'] = $type;
			if($type==0) $this->setLogs(1);
		}else 
			$this->type = false;	
		return $this;
	}
	
	#GET TYPE
	public function getType(){
		return $this->type;
	}
	
	#SET LOGS
	public function setLogs($v){
		$j = new JUDGES;
		$j->log($this->getUid(), $v);
		return $this;
	}

	#SET TIME
	public function setTime($time=null){
		if(!is_null($time)) {
			$this->time = $time;
			$_SESSION[$this->webSession]['time'] = $time;
		}else 
			$this->time = false;
		return $this;
	}
	
	#GET TIME
	public function getTime(){
		return $this->time;
	}
	
	#Checks if user is logged in
	public function isLogged() {
		return isset($_SESSION[$this->webSession])? true : false;
	}

	public function getLink() {
		$link = null;
		if($this->isLogged()){
			switch ($this->getType()) {
				case 1:
					$link = generateUrl(MAIN_CLASS.'/admin/account');
				break;
				default:
					$link = generateUrl(MAIN_CLASS.'/user/account');
				break;
			}
			return $link;
		}
		return false;
	}
}
