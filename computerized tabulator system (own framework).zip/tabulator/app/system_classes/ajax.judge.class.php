<?php
class judgeAJAX {
	public $post, $data, $juds, $user;
	public function __construct($data) {
		$this->data = $data;
		$this->post = @$_POST['d'];
		$this->juds = new JUDGES;
		$this->user = new USERS;
	}

	public function get_data(){
		return $this->data;
	}
	
	public function get_post(){
		return $this->post;
	}

	public function set_post($post){
		$this->post = $post;
		return $this;
	}

	public function add(){
		$d = $this->get_data();
		if($d['p']==$d['c']){
			$u = $this->user->create($d['u'], $d['c']);
			$r = $this->juds->add($d['n'], $d['d'], $d['e'], $u);
			if($r){
				$_SESSION[$this->juds->message] = 'Judge successfully added.';
				return 1;
			} else
				return 'Error adding...';
		} else
			return 'Confirm Password';
	}

	public function ups(){
		$d = $this->get_data();
		$e = 'Error editing...';
		if($d['upass']==$d['cpass']){
			$r = $this->juds->ups($d['name'], $d['description'], $d['event'], $d['_user'], $d['uid'], $d['id']);
			if($r){
				if(empty($d['upass'])){
					$_SESSION[$this->juds->message] = 'Judge successfully edited.';
					return 1;
				} else {
					$this->user->update($d['upass'], $d['uid']);
					if($d['upass']==$this->user->getContent($this->user->getShadow($d['uid']).'.txt')){
						$_SESSION[$this->juds->message] = 'Judge successfully edited.';
						return 1;
					} else
						return $e;
				}
			} else 
				return $e;
		} else 
			return 'Confirm Password';
	}

	public function del(){
		$s = new SCORES;
		$c = 0;
		foreach ($this->get_post() as $d){
			$j = $this->juds->row($d);
			if($this->juds->del($j['id'])){
				if($this->user->remove($j['uid'])){ 
					$s->del($j['uid'], 1);
					$c++;
				}
			}
		}
		if($c>0){
			$e = ($c==1)? 'Judge' : ($c .' Judges');
			$_SESSION[$this->juds->message] = $e . ' successfully deleted.';
			return 1;
		} else
			return 'Error deleting...';
	}

	public function get(){
		$d = $this->get_post();
		return json_encode($this->juds->row($d));
	}

	public function clr(){
		if(isset($_SESSION[$this->juds->message])) unset($_SESSION[$this->juds->message]);
		return $this;
	}
}


