<?php
class userPage {
	public $usr, $req, $acc, $jud, $das;
	function __construct($request=null) {
		$this->req = $request;
	    $this->das = new DASH;
		$this->jud = new JUDGES;
		$this->usr = new SESSIONS;
		$this->acc = array(
			"menu" => getViewsContents('menu'),
			"title" => "Account | " . WEB_TITLE,
			"content" => getViewsContents('account')
		);
	}
	public function page_() {
		return $this->page_signin();
	}
	public function page_signin() {
		if($this->usr->isLogged()){
			header('Location: ' . $this->usr->getLink());
			exit;
		} else
			return array(
				"menu" => null,
				"title"	=> "Sign In | " . WEB_TITLE,
				"content" => getViewsContents('login')
			);
	}
	public function page_signout() {
		if($this->usr->getType()==0) $this->usr->setLogs(0);
		else { 
			$dashAJAX = new dashAJAX;
			$dashAJAX->backupDB();
			$dashAJAX->clearXLS();
			$dashAJAX->clearIMG();
		}
		session_destroy();
		clearstatcache();
		header('Location: ' . baseURL());
		exit;
	}
	public function page_account(){ 
		if($this->usr->isLogged()){
			if($this->usr->getType()==0){
				if($this->jud->chk($this->usr->getUid())==0){
					header('Location: ' . generateUrl(PAGE_HALT));
					exit;
				}
			}
			return $this->acc;
		} else {
			header('Location: ' . generateUrl(PAGE_HOME));
			exit;
		}
	}
	public function page_dashboard(){ 
		if($this->usr->isLogged()){
			if($this->usr->getType()==0){
				$data = $this->das->getDash();
				if($this->jud->eid($this->usr->getUid())==$data['event']){
					return array(
						"menu" => getViewsContents('menu'),
						"title" => "Dashboard | " . WEB_TITLE,
						"content" => getViewsContents('userboard')
					);
				} else {
					header('Location: ' . generateUrl(PAGE_HOME));
					exit;
				}
			} else {
				header('Location: ' . generateUrl(str_replace('user', 'admin', PAGE_DASH)));
				exit;
			}
		} else {
			header('Location: ' . generateUrl(PAGE_HOME));
			exit;
		}
	}
	public function page_contestant(){ 
		if($this->usr->isLogged()){
			if($this->usr->getType()==0){
				$data = $this->das->getDash();
				if($this->jud->eid($this->usr->getUid())==$data['event'] AND arg(4)){
					return array(
						"menu" => getViewsContents('menu'),
						"title" => "Contestant | " . WEB_TITLE,
						"content" => getViewsContents('edit')
					);
				} else {
					header('Location: ' . generateUrl(PAGE_HOME));
					exit;
				}
			} else {
				header('Location: ' . generateUrl(str_replace('user', 'admin', PAGE_DASH)));
				exit;
			}
		} else {
			header('Location: ' . generateUrl(PAGE_HOME));
			exit;
		}
	}
}

class adminPage extends userPage {
	function __construct($request=null){
		parent::__construct();
		if($this->usr->isLogged()){
			if($this->usr->getType()==0){
				header('Location: ' . $this->usr->getLink());
				exit;
			}
		} else {
			header('Location: ' . generateUrl(PAGE_HOME));
			exit;
		}
		$this->req = $request;
	}
	public function page_dashboard(){ 
		return array(
			"menu" => getViewsContents('menu'),
			"title" => "Dashboard | " . WEB_TITLE,
			"content" => getViewsContents('dashboard')
		);
	}
	public function page_account(){ 
		return $this->acc;
	}
	public function page_event(){
		return array(
			"menu" => getViewsContents('menu'),
			"title" => "Event | " . WEB_TITLE,
			"content" => getViewsContents('event')
		);
	}
	public function page_criteria(){
		$arg4 = arg(4);
		$evnt = new EVENTS;
		$data = $evnt->get();
		$keys = array();
		foreach($data as $d) $keys[] = $d['id'];
		if(is_numeric($arg4) AND in_array($arg4, $keys))
			return array(
				"menu" => getViewsContents('menu'),
				"title" => "Criteria | " . WEB_TITLE,
				"content" => getViewsContents('criteria')
			);
		else {
			header('Location: ' . generateUrl(MAIN_CLASS.'/admin/event'));
			exit;
		}
	}
	public function page_contestant(){
		return array(
			"menu" => getViewsContents('menu'),
			"title" => "Contestant | " . WEB_TITLE,
			"content" => getViewsContents('contestant')
		);
	}
	public function page_judge(){
		return array(
			"menu" => getViewsContents('menu'),
			"title" => "Judge | " . WEB_TITLE,
			"content" => getViewsContents('judge')
		);
	}
}
