<?php 
   $form = new HTML_Form;
   $event = new EVENTS; 
   $dash = new DASH;
   $data = $dash->getDash();
   $link = MAIN_CLASS . '/admin/event';
?>
<div class="container bg">
   <div class="row">
      <div class="span3"><?php print getViewsContents('side'); ?></div>
      <div class="span9">
         <div class="pagetitle">
            <h2>Event</h2>
            <p>Some description about this page</p>
         </div>
         <div id="main-content">
            <?php
               if(isset($_SESSION[$event->message])){ 
                  print messageBox($_SESSION[$event->message]); 
                  unset($_SESSION[$event->message]); 
               }
            ?>
            <div class="box">
               <div class="header">
                  <h4><span class="icon_application-form"></span>List</h4>
                  <div class="box-control pull-right">
                     <a class="btn dropdown-toggle" data-toggle="dropdown" href="#" data-original-title="Actions"><i class="icon-cog"></i></a>
                     <ul class="dropdown-menu">
                        <li id="add"><a href="#" data-original-title="Add Event"><i class="icon-plus"></i>Add</a></li>
                        <li id="ups" ca="checkbox-uniform" ax="event/getEvent"><a href="#" data-original-title="Edit Event"><i class="icon-edit"></i>Edit</a></li>
                        <li id="del" ca="checkbox-uniform" ax="event/delEvent" hl="<?php echo $link; ?>">
							<a href="#" data-original-title="Delete Event"><i class="icon-remove"></i>Delete</a>
						</li>
						<li class="act" ca="checkbox-uniform" ax="event/actEvent" hl="<?php echo $link; ?>" at="activate">
							<a href="#" data-original-title="Activate Event"><i class="icon-ok-circle"></i>Activate</a>
						</li>
						<li class="act" ca="checkbox-uniform" ax="event/deaEvent" hl="<?php echo $link; ?>" at="deactivate">
							<a href="#" data-original-title="Deactivate Event"><i class="icon-ban-circle"></i>Deactivate</a>
						</li>
                        <li id="all" ca="checkbox-uniform"><a href="#" data-original-title="Check All"><i class="icon-list"></i><span class="all">Check All</span></a></li>
                        <li id="ref"><a href="#" data-original-title="Refresh"><i class="icon-refresh"></i>Refresh</a></li>
                     </ul>
                  </div>
               </div>
               <div class="content" id="nopad">
                  <table class="normal bt-dataTable" border="0" cellpadding="0" cellspacing="0" width="100%" id="dataTable">
                     <thead>
                        <tr>
                           <th class="chk">&nbsp;</th>
                           <th>Name</th>
                           <th>Description</th>
                           <th>Venue</th>
                           <th>Status</th>
                        </tr>
                     </thead>
                     <tbody>
                     <?php foreach ($event->get() as $d): ?>
                        <tr class="gradeX">
                           <td class="tal">
                              <label class="checkbox inline">
                                 <input type="checkbox" class="checkbox-uniform" value="<?php print $d['id']; ?>">
                              </label>
                           </td>
                           <td><?php print stripslashes($d['name']); ?></td>
                           <td><?php print stripslashes($d['description']); ?></td>
                           <td><?php print stripslashes($d['venue']); ?></td>
                           <td><?php print ($d['status']==0)? '<span class="label"><i class="icon-lock"></i> Inactive</span>' : 
							'<span class="label '.(($d['id']==$data['event'])? 'label-success' : 'label-info').'" eid="'.$d['id'].'"><i class="icon-cog"></i>Active</span>'; ?></td>
                        </tr>
                     <?php endforeach; ?>
                     </tbody>
                  </table>
               </div>
            </div>
            <div class="clear"></div>
         </div>
      </div>
   </div>
</div>
<div class="add">
<?php 
   $rand = random_string(5);
   $attr = array(
               'name' => 'add_event',
               'class' => 'form-horizontal system',
               'location' => $link,
               'filter' => $rand
   );
   $addform = $form->startForm("event/addEvent", "post", "add_event", $attr).$form->endForm(); 
?>
   <div class="rowelement pop">
      <div class="span3"> Name: </div>
      <div class="span3"><input class="input-large <?php echo $rand; ?>" type="text" name="name"/></div>
      <div class="clear"></div>
   </div>
   <div class="rowelement pop">
      <div class="span3"> Description: </div>
      <div class="span3"><textarea class="input-large <?php echo $rand; ?>" name="desc"></textarea></div>
      <div class="clear"></div>
   </div>
   <div class="rowelement pop">
      <div class="span3"> Venue: </div>
      <div class="span3"><textarea class="input-large <?php echo $rand; ?>" name="venu"></textarea></div>
      <div class="clear"></div>
   </div>
</div>
<div class="ups">
<?php 
   $rand = random_string(5);
   $attr = array(
               'name' => 'ups_event',
               'class' => 'form-horizontal system',
               'location' => $link,
               'filter' => $rand
   );
   $upsform = $form->startForm("event/upsEvent", "post", "ups_event", $attr).$form->endForm(); 
?>
   <input class="input-large <?php echo $rand; ?>" type="hidden" name="id"/>
   <div class="rowelement pop">
      <div class="span3"> Name: </div>
      <div class="span3"><input class="input-large <?php echo $rand; ?>" type="text" name="name"/></div>
      <div class="clear"></div>
   </div>
   <div class="rowelement pop">
      <div class="span3"> Description: </div>
      <div class="span3"><textarea class="input-large <?php echo $rand; ?>" name="description"></textarea></div>
      <div class="clear"></div>
   </div>
   <div class="rowelement pop">
      <div class="span3"> Venue: </div>
      <div class="span3"><textarea class="input-large <?php echo $rand; ?>" name="venue"></textarea></div>
      <div class="clear"></div>
   </div>
</div>
<script type="text/javascript">
$(document).ready(function(){
   $("#ref").click(function(){ Redirect('<?php echo $link; ?>'); })
   $("div.checker").css({"margin-left":0,"margin-right":0, "padding":0});
   $('.pop').css({"padding":0});
   $(".add, .ups").css({"overflow":"hidden"});
   $("#add").add('<?php print $addform; ?>', 'Add Event', $("div.add"), 300, true, 'bart', true, 'save', 'save', 'btn btn-primary', 'Save', 'Cancel');
   $('#ups').ups('<?php print $upsform; ?>', 'Edit Event', $("div.ups"), 300, true, 'dogz', 
   function(obj){
     $("div.ups").find('textarea').each(function(){
        $(this).html(obj[$(this).attr('name')]);
     });
     return true;
   }, 'save', 'save', 'btn btn-primary', 'Save', 'Cancel');
   $('#all').all($('span.all'));
   $('#del').del();
   $('.act').act();
   $('span.label-success, span.label-info').css({"cursor":"pointer"}).attr('data-placement','right').attr('data-original-title', 'Manage Criteria').tooltip()
   .click(function(){ Redirect('<?php echo str_replace("event", "criteria", $link); ?>/'+$(this).attr('eid')); })
});
</script>
