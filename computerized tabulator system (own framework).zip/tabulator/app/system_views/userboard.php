<?php
   $dash = new DASH;
   $data = $dash->getDash();
   $tool = $dash->getCriteria();
   $link = PAGE_DASH;
?>
<div class="container bg">
   <div class="row">
      <div class="span3"><?php print getViewsContents('side'); ?>
	  	 <div class="sidebar tb mt20">
		     <div class="sidebar-wrap padding-reset">
		        <table class="cool" ax="dash/jr" data-placement="top" data-original-title="Ranking based on <?php echo $tool['criteria']; ?>">
		           <thead>
		              <tr>
		                 <td>#</td>
		                 <td>Contestant</td>
		                 <td>Score</td>
		              </tr>
		           </thead>
				   <tbody>
					  <tr>
		                 <td colspan="3"><img src="<?php echo BASEURL; ?>images/elements/file_manager/spinner.gif"></td>
		              </tr>
				   </tbody>
		        </table>
		     </div>
		  </div>
	  </div>
      <div class="span9">
         <div class="pagetitle">
            <h2>Dashboard</h2>
            <p>Some description about this page</p>
         </div>
         <div id="main-content">
			<?php
               if(isset($_SESSION[$dash->message])){ 
                  print messageBox($_SESSION[$dash->message]); 
                  unset($_SESSION[$dash->message]); 
               }
            ?>
			<div class="row-fluid grid-set">
				<div class="span6">
					<div class="box sb" ax="dash/ge">
						<div class="header"><h4></h4>
							<div class="box-control pull-right">
                                <a class="btn dropdown-toggle" data-toggle="dropdown" href="#" data-original-title="Actions"><i class="icon-cog"></i></a>
                                <ul class="dropdown-menu">
                                   <li class="sc" ax="dash/sc" hl="<?php echo $link; ?>"><a href="#" data-original-title="Save"><i class="icon-ok"></i> Save</a></li>
								   <li class="ec" ax="dash/gc" hl="<?php echo $link; ?>"><a href="#" data-original-title="Edit"><i class="icon-pencil"></i> Edit</a></li>
                                </ul>
                             </div>
						</div>
						<div class="content pad"></div>
					</div>
					<div class="box progress-bar">
						<div class="header"><h4>Progress</h4></div>
						<div class="content pad">
							<div class="progress total" ax="dash/pb"></div>
							<div class="progress break" ax="dash/sb"></div>
						</div>
					</div>
				</div>
				<div class="span6">
					<div class="box ac" ax="dash/gp">
						<div class="header"><h4></h4></div>
						<div class="content"><img></div>
					</div>
				</div>
            	<div class="clear"></div>
         </div>
      </div>
   </div>
</div>
<script type="text/javascript">
$(document).ready(function(){
   var MIN = <?php echo MIN_SCORE; ?>;
   var MAX = <?php echo MAX_SCORE; ?>;
   $(".progress-bar").css({"margin-top":"30px"});
   setInterval(function(){ setReload(); }, 1000);
   setLeftBoard();
   setRightBoard();
   setProgress();
   setRank();
   function sum(){
		var sum = 0;
		$("span.help-inline").each(function(){ sum += parseFloat($(this).html()); });
		return (sum%1==0)? sum : sum.toFixed(2);
   }
   function setLeftBoard(){
		var div = $("div.sb");
   		$.ajax({
           url:BASEURL + "ajax.php?q=" + div.attr('ax'),
           type:"POST",
           data:{ d : 0 },
           dataType:"html"
        }).done(function(e){
		   	var r = $.parseJSON(e);
       	   	div.find('h4').text(r['name']);
			$.ajax({
		       url:BASEURL + "ajax.php?q=" + div.attr('ax').replace("e","c"),
		       type:"POST",
		       data:{ d : 0 },
		       dataType:"html"
		    }).done(function(e){
			   var r = $.parseJSON(e);
			   var t = $('<span class="label label-warning" data-placement="left" data-original-title="Total Score"></span>').addClass('pointer')
			   .css({"padding-top":"5px","float":"right","color":"#777","margin":"5px 0 20px 0"}).tooltip();
		   	   $.each(r, function(i,d){
					var pv = (d['score'] * d['percentage'])/100;
					var sp = $('<span class="help-inline label label-warning">'+pv+'</span>').css({"padding-top":"5px","float":"right","margin-top":"5px"});
					if(d['status']==1){
						var tb = $('<input type="text" class="input-mini" value="'+((d['score']==null)? '' : d['score'])+'" cid="'+d['id']+'">')
						.css({"text-align":"center"})
						.filter_input({regex:'[0-9]'})
						.change(function(){
							if($(this).val()>MAX){ 
								popup_box({content:"Maximum score is "+MAX+"."}, {close:"OK"});
								$(this).val(MAX);
							} else if($(this).val()<MIN) {
								popup_box({content:"Minimum score is "+MIN+"."}, {close:"OK"});
								$(this).val(MIN);
							}
							$(sp).html(($(this).val() * d['percentage'])/100);
							t.html(sum());
						});
					} else var tb = $('<input type="text" value="'+((d['score']==null)? '' : d['score'])+'" readonly>').css({"text-align":"center","width":"60px"});
					var wd = $("<div></div>").css({"overflow":"hidden"});
					var ld = $("<div></div>").html(d['criteria']+' - '+d['percentage']+'%').css({"width":"50%","float":"left", "padding-top":"5px"});
					var rd = $("<div></div>").css({"width":"50%","float":"right"}).append(tb).append(sp);
					$(wd).append(ld).append(rd);
					div.find('div.content').append(wd);		
			   });
			   var rd = $("<div></div>").css({"width":"50%","float":"right"}).append(t.html(sum()));
			   var wd = $("<div></div>").css({"overflow":"hidden"}).append(rd);
		       div.find('div.content').append(wd);
			   var bs = $('<input type="button" class="btn btn-primary" ax="'+div.find('li.sc').attr('ax')+'" hl="'+div.find('li.sc').attr('hl')+'" value="Save">')
			   .css({"width":"70px","float":"right"}).click(function(){ div.find('li.sc').click(); });
			   var rd = $("<div></div>").css({"width":"50%","float":"right"}).append(bs);
			   var wd = $("<div></div>").css({"overflow":"hidden"}).append(rd);
			   div.find('div.content').append(wd);
		    }).fail(function(jqXHR, textStatus) {
		       popup_box({content:"setLeftBoard(): " + textStatus});
		    });
        }).fail(function(jqXHR, textStatus) {
           popup_box({content:"setLeftBoard(): " + textStatus});
        });
   }
   function setRightBoard(){
        var div = $("div.ac").addClass('pointer');
   		$.ajax({
           url:BASEURL + "ajax.php?q=" +  div.attr('ax'),
           type:"POST",
           data:{ d : 0 },
           dataType:"html"
        }).done(function(e){
		   var r = $.parseJSON(e);
		   div.find('div.content').css({"padding":"1px"});
           div.find('img').attr('src', BASEURL + 'upl/' + r['photo']).css({"margin":0,"padding":0,"width":"100%","border-radius":"0 0 3px 3px"});
		   div.find('h4').text(r['number']+' - '+r['name']);
		   div.attr('data-placement', 'top').attr('data-original-title', r['address']).tooltip();
        }).fail(function(jqXHR, textStatus) {
           popup_box({content:"setRightBoard(): " + textStatus});
        });
   }
   function setReload(){
		var link = '<?php echo $link; ?>';
		$.ajax({
           url:BASEURL + "ajax.php?q=dash/gd",
           type:"POST",
           data:{ d : 0 },
           dataType:"html"
        }).done(function(e){
		   var r = $.parseJSON(e);
		   if(r['event']==<?php echo $data['event']; ?>){
			   if(r['criteria']==<?php echo $data['criteria']; ?>){
			       if(r['contestant']==<?php echo $data['contestant']; ?>) return true;
			       else Redirect(link);
			   } else Redirect(link);
		   } else Redirect('<?php echo PAGE_HOME; ?>');
        });
   }
   function setRank(){
		var tbl = $("table.cool").addClass('pointer');
		$.ajax({
           url:BASEURL + "ajax.php?q=" + tbl.attr('ax'),
           type:"POST",
           data:{d:1},
           dataType:"html"
        }).done(function(e){
		   var n = 1;
		   var r = $.parseJSON(e);
		   tbl.find('tbody').remove();
		   $.each(r, function(i,d){
				var d1 = $('<td></td>', {class:"tac"}).html('<span>'+n+'</span>');
				var d2 = $('<td></td>').html(d['name']);
				var d3 = $('<td></td>', {class:"text-blue tac"}).html(d['score']);
				var tr = $('<tr></tr>').append(d1).append(d2).append(d3);
				var tb = $('<tbody></tbody>').append(tr);
				tbl.append(tb).tooltip();
				n++;
		   });
        }).fail(function(jqXHR, textStatus) {
           popup_box({content:"setRank(): " + textStatus});
        });
   }
   function setProgress(){
		var divTotal = $("div.progress.total").css({"margin":"2px"});
		var divBreak = $("div.progress.break").css({"margin":"10px 2px 2px 2px"});
		$.ajax({
           url:BASEURL + "ajax.php?q=" + divTotal.attr('ax'),
           type:"POST",
           data:{d:1},
           dataType:"html"
        }).done(function(e){
			var r = $.parseJSON(e);
			var span= $('<span></span>').html(r['progress']+'%');
			var div = $('<div></div>', {class:"bar", "data-placement":"top", "data-original-title":r['criteria']}).css({"width":r['progress']+"%"}).append(span).tooltip();
			divTotal.append(div.addClass('pointer'));
		});
		$.ajax({
           url:BASEURL + "ajax.php?q=" + divBreak.attr('ax'),
           type:"POST",
           data:{d:1},
           dataType:"html"
        }).done(function(e){
			var r = $.parseJSON(e);
			$.each(r, function(i,d){
				var span= $('<span></span>').html(d['percentage']+'%');
				var div = $('<div></div>', {class:d['class'], "data-placement":"top", "data-original-title":d['criteria']}).css({"width":d['percentage']+"%"}).append(span).tooltip();
				divBreak.append(div.addClass('pointer'));
		    });
		});
   }
   $(".sc").click(function(){ 
		var ax = $(this).attr('ax');
		var hl = $(this).attr('hl');
		var sc = new Array;
    	$("input.input-mini").each(function(){
			var data = new Object;
			data.cid = $(this).attr("cid");
			data.val = $(this).attr("value");
        	sc.push(data);
      	});
		if(sc.length) {
			$.ajax({
		       url:BASEURL + "ajax.php?q=" + ax,
		       type:"POST",
		       data:{ d : sc },
		       dataType:"html"
		    }).done(function(e){
		       if(isNaN(e)) popup_box({content:e}); 
		       else $(location).attr("href", BASEURL + ((FREEURL)? "":"?q=") + hl);
		    }).fail(function(jqXHR, textStatus) {
		       popup_box({content:"sc: " + textStatus});
		    });
		}
   });
   $(".ec").click(function(){
		var obj = $(this);
		var div = $("div.sb");
		obj.hide();
		div.find('div.content').empty();
		$.ajax({
	       url:BASEURL + "ajax.php?q=" + obj.attr('ax'),
	       type:"POST",
	       data:{ d : 0 },
	       dataType:"html"
	    }).done(function(e){
		   var r = $.parseJSON(e);
		   var t = $('<span class="label label-warning" data-placement="left" data-original-title="Total Score"></span>').addClass('pointer')
		   .css({"padding-top":"5px","float":"right","color":"#777","margin":"5px 0 20px 0"}).tooltip();
	   	   $.each(r, function(i,d){
				var pv = (d['score'] * d['percentage'])/100;
				var sp = $('<span class="help-inline label label-warning">'+pv+'</span>').css({"padding-top":"5px","float":"right","margin-top":"5px"});
				if(d['score']==null) var tb = $('<input type="text" readonly>').css({"text-align":"center","width":"60px"});
				else {
					var tb = $('<input type="text" class="input-mini" value="'+d['score']+'" cid="'+d['id']+'">')
					.css({"text-align":"center"})
					.filter_input({regex:'[0-9]'})
					.change(function(){
						if($(this).val()>MAX){ 
							popup_box({content:"Maximum score is "+MAX+"."}, {close:"OK"});
							$(this).val(MAX);
						} else if($(this).val()<MIN) {
							popup_box({content:"Minimum score is "+MIN+"."}, {close:"OK"});
							$(this).val(MIN);
						}
						$(sp).html(($(this).val() * d['percentage'])/100);
						t.html(sum());
					});
				}
				var wd = $("<div></div>").css({"overflow":"hidden"});
				var ld = $("<div></div>").html(d['criteria']+' - '+d['percentage']+'%').css({"width":"50%","float":"left", "padding-top":"5px"});
				var rd = $("<div></div>").css({"width":"50%","float":"right"}).append(tb).append(sp);
				$(wd).append(ld).append(rd);
				div.find('div.content').append(wd);		
		   });
		   var rd = $("<div></div>").css({"width":"50%","float":"right"}).append(t.html(sum()));
		   var wd = $("<div></div>").css({"overflow":"hidden"}).append(rd);
	       div.find('div.content').append(wd);
		   var bs = $('<input type="button" class="btn btn-primary" ax="'+div.find('li.sc').attr('ax')+'" hl="'+div.find('li.sc').attr('hl')+'" value="Save">')
		   .css({"width":"70px","float":"right"}).click(function(){ div.find('li.sc').click(); });
		   var bc = $('<input type="button" class="btn btn-soft-gray" value="Exit">').css({"width":"70px","float":"right","margin-left":"1px"}).click(function(){ 
				div.find('div.content').empty();
				setLeftBoard();				
				obj.show(); 
		   });
		   var rd = $("<div></div>").css({"width":"50%","float":"right"}).append(bc).append(bs);
		   var wd = $("<div></div>").css({"overflow":"hidden"}).append(rd);
		   div.find('div.content').append(wd);
	    }).fail(function(jqXHR, textStatus) {
	       popup_box({content:"ec: " + textStatus});
	    });
   });
});
</script>
