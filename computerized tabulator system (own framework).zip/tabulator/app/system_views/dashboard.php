<?php
   $dash = new DASH;
   $data = $dash->getDash();
   $tool = $dash->getCriteria();
   $link = str_replace('user', 'admin', PAGE_DASH);
?>
<div class="container bg">
   <div class="row">
      <div class="span3"><?php print getViewsContents('side'); ?>
	  	 <div class="sidebar tb mt20">
		     <div class="sidebar-wrap padding-reset">
		        <table class="cool" ax="dash/cl">
		           <thead>
		              <tr>
		                 <td>#</td>
		                 <td>Contestant</td>
		                 <td>Score</td>
		              </tr>
		           </thead>
				   <tbody>
					  <tr>
		                 <td colspan="3" class="sp"></td>
		              </tr>
				   </tbody>
		        </table>
		     </div>
		  </div>
	  </div>
      <div class="span9">
         <div class="pagetitle">
            <h2>Dashboard</h2>
            <p>Some description about this page</p>
         </div>
         <div id="main-content">
			<?php
               if(isset($_SESSION[$dash->message])){ 
                  print messageBox($_SESSION[$dash->message]); 
                  unset($_SESSION[$dash->message]); 
               }
            ?>
            <div class="row-fluid grid-set">
				<div class="span4">
					<div class="box">
						<div class="header"><h4>Event</h4>
							<div class="box-control pull-right">
                                <a class="btn dropdown-toggle" data-toggle="dropdown" href="#" data-original-title="Action"><i class="icon-cog"></i></a>
                                <ul class="dropdown-menu">
								   <li id="pre" ax="dash/pre" ae="<?php echo $data['event']; ?>"><a href="#" data-original-title="Print Result"><i class="icon-print"></i> Print Result</a></li>
                                   <li id="rs" ax="dash/rs" hl="<?php echo $link; ?>"><a href="#" data-original-title="Reset Score"><i class="icon-refresh"></i> Reset Score</a></li>
                                </ul>
                             </div>
						</div>
						<div class="content pad">
							<select data-placeholder="Event" class="chzn-select input-large" tabindex="1" id="ev" ax="dash/ev" hl="<?php echo $link; ?>">
							<?php foreach($dash->getEvents() as $d): ?>
		                    	<option value="<?php echo $d['id']; ?>" <?php if($d['id']==$data['event']) echo 'selected'; ?>>
									<?php echo stripslashes($d['name']); ?>
								</option>
							<?php endforeach; ?>
		                    </select>
						</div>
					</div>
				</div>
				<div class="span4">
					<div class="box">
						<div class="header"><h4>Criteria</h4>
							<div class="box-control pull-right">
                                <a class="btn dropdown-toggle" data-toggle="dropdown" href="#" data-original-title="Action"><i class="icon-cog"></i></a>
                                <ul class="dropdown-menu">
                                   <li id="vr" ax="dash/vr" cn="<?php echo $tool['criteria']; ?>" ac="<?php echo $data['criteria']; ?>">
										<a href="#" data-original-title="View Ranking"><i class="icon-list"></i> View Ranking</a>
								   </li>
                                </ul>
                             </div>
						</div>
						<div class="content pad">
							<select data-placeholder="Criteria" class="chzn-select input-large" tabindex="2" id="cr" ax="dash/cr" hl="<?php echo $link; ?>">
							<?php foreach($dash->getCriterias() as $d): $option = stripslashes($d['criteria']).' - '.$d['percentage'].'%'; ?>
		                    	<option value="<?php echo $d['id']; ?>" <?php if($d['id']==$data['criteria']) echo 'selected'; ?>><?php echo $option; ?></option>
							<?php endforeach; ?>
		                    </select>
						</div>
					</div>
				</div>
				<div class="span4">
					<div class="box">
						<div class="header"><h4>Contestant</h4></div>
						<div class="content pad">
							<select data-placeholder="Contestant" class="chzn-select input-large" tabindex="3" id="co" ax="dash/co" hl="<?php echo $link; ?>">
							<?php foreach($dash->getContestants(null, 0) as $d): $option = $d['number'].' - '.stripslashes($d['name']); ?>
		                    	<option value="<?php echo $d['id']; ?>" <?php if($d['id']==$data['contestant']) echo 'selected'; ?>><?php echo $option; ?></option>
							<?php endforeach; ?>
		                    </select>
						</div>
					</div>
				</div>
			</div>
            <div class="clear"></div>
			<div class="row-fluid grid-set">
				<div class="span8">
					<div class="box">
						<div class="header"><h4>Activated Contestant</h4>
							<div class="box-control pull-right">
                                <a class="btn dropdown-toggle" data-toggle="dropdown" href="#" data-original-title="Actions"><i class="icon-cog"></i></a>
                                <ul class="dropdown-menu">
                                   <li><a href="#" class="ar" data-original-title="Remove All" ax="dash/ra" hl="<?php echo $link; ?>" dv="0"><i class="icon-remove"></i> Remove All</a></li>
                                </ul>
                             </div>
						</div>
						<div class="content pad">
						<?php foreach($dash->getContestants(1, 0) as $d): $option = $d['number'].' - '.stripslashes($d['name']); ?>
							<div class="btn-group dropup">
								<button class="btn" data-original-title="<?php echo $option; ?>"><?php echo $option; ?></button>
								<button data-toggle="dropdown" class="btn dropdown-toggle" data-original-title="Actions"><span class="caret"></span></button>
								<ul class="dropdown-menu">
									<li><a href="#" class="ar" ax="dash/ac" hl="<?php echo $link; ?>" dv="<?php echo $d['id']; ?>"><i class="icon-ok"></i> Activate</a></li>
									<li><a href="#" class="ar" ax="dash/ar" hl="<?php echo $link; ?>" dv="<?php echo $d['id']; ?>"><i class="icon-remove"></i> Remove</a></li>
									<li><a href="#" class="ar" ax="dash/ec" hl="<?php echo $link; ?>" dv="<?php echo $d['id']; ?>"><i class="icon-ban-circle"></i> Eliminate</a></li>
								</ul>
							</div>
						<?php endforeach; ?>
						</div>
					</div>
					<?php 
						$i = 0;
						$e = $dash->getEliminated();
						foreach($e as $d) $i++;
						if($i > 0):
					?>
					<div class="box eliminated">
						<div class="header"><h4>Eliminated Contestant</h4>
							<div class="box-control pull-right">
                                <a class="btn dropdown-toggle" data-toggle="dropdown" href="#" data-original-title="Action"><i class="icon-cog"></i></a>
                                <ul class="dropdown-menu">
                                   <li><a href="#" class="ar" data-original-title="Remove All" ax="dash/re" hl="<?php echo $link; ?>" dv="0"><i class="icon-remove"></i> Remove All</a></li>
                                </ul>
                             </div>
						</div>
						<div class="content pad">
						<?php foreach($dash->getEliminated() as $d): $option = $d['number'].' - '.stripslashes($d['name']); ?>
							<div class="btn-group dropup">
								<button class="btn" data-original-title="<?php echo $option; ?>"><?php echo $option; ?></button>
								<button data-toggle="dropdown" class="btn dropdown-toggle" data-original-title="Action"><span class="caret"></span></button>
								<ul class="dropdown-menu">
									<li><a href="#" class="ar" ax="dash/er" hl="<?php echo $link; ?>" dv="<?php echo $d['id']; ?>"><i class="icon-repeat"></i> Remove</a></li>
								</ul>
							</div>
						<?php endforeach; ?>
						</div>
					</div>
					<?php endif; ?>
					<div class="box judges" ax="dash/jv">
						<div class="header"><h4>Judge</h4></div>
						<div class="content pad"></div>
					</div>
					<div class="box progress-bar">
						<div class="header"><h4>Progress</h4></div>
						<div class="content pad">
							<div class="progress total" ax="dash/pb">
								<div class="bar"><span></span></div>
							</div>
							<div class="progress break" ax="dash/sb"></div>
						</div>
					</div>
				</div>
				<div class="span4">
					<div class="box ac">
						<div class="header"><h4>Active Contestant</h4></div>
						<div class="content gp"><img id="active" ax="dash/gp"></div>
					</div>
				</div>
            	<div class="clear"></div>
         </div>
      </div>
   </div>
</div>
<script type="text/javascript">
$(document).ready(function(){
   var spinner = '<img src="'+BASEURL+'images/elements/file_manager/spinner.gif">';
   setDash($("#ev"));
   setDash($("#cr"));
   setDash($("#co"));
   setPhoto($("#active").css({"margin":0,"padding":0,"width":"100%","border-radius":"0 0 3px 3px"}));
   setInterval(function(){ 
   		setJudge(); 
		setRank();
		setProgress();
   }, 5000);
   $("div.judges").find('div.content').html(spinner);
   $("div.progress-bar").find('div.content').append(spinner).find('div.progress').hide();
   $(".sp").html(spinner);
   $(".gp").css({"padding":"1px"});
   $(".dropup").css({"margin":"2px"});
   $(".eliminated, .judges, .progress-bar").css({"margin-top":"4.5%"});
   $("#ev, #cr, #co").change(function(){ 
		var ax = $(this).attr('ax');
		var hl = $(this).attr('hl');
		var sv = $(this).val();
		$.ajax({
           url:BASEURL + "ajax.php?q=" + ax,
           type:"POST",
           data:{ d : sv },
           dataType:"html"
        }).done(function(e){
           if(isNaN(e)) popup_box({content:e}); 
           else $(location).attr("href", BASEURL + ((FREEURL)? "":"?q=") + hl);
        }).fail(function(jqXHR, textStatus) {
           popup_box({content:"ev, cr, co: " + textStatus});
        });
   });
   $(".ar").click(function(){ 
		var ax = $(this).attr('ax');
		var hl = $(this).attr('hl');
		var dv = $(this).attr('dv');
		$.ajax({
           url:BASEURL + "ajax.php?q=" + ax,
           type:"POST",
           data:{ d : dv },
           dataType:"html"
        }).done(function(e){
           if(isNaN(e)) popup_box({content:e}); 
           else $(location).attr("href", BASEURL + ((FREEURL)? "":"?q=") + hl);
        }).fail(function(jqXHR, textStatus) {
           popup_box({content:"ar: " + textStatus});
        });
   });
   $("#rs").click(function(){
		var ax = $(this).attr('ax');
		var hl = $(this).attr('hl');
		if(confirm("This action cannot be undone. Do you want to proceed?")){
			$.ajax({
		       url:BASEURL + "ajax.php?q=" + ax,
		       type:"POST",
		       data:{ d : $("#ev").val() },
		       dataType:"html"
		    }).done(function(e){
		       if(isNaN(e)) popup_box({content:e}); 
		       else $(location).attr("href", BASEURL + ((FREEURL)? "":"?q=") + hl);
		    }).fail(function(jqXHR, textStatus) {
		       popup_box({content:"ar: " + textStatus});
		    });
		}
   });
   $("#vr").click(function(){
		var vr = $(this);
		var ax = $(this).attr('ax');
		var cn = $(this).attr('cn');
		var ac = $(this).attr('ac');
		$.ajax({
	       url:BASEURL + "ajax.php?q=" + ax,
	       type:"POST",
	       data:{d:ac, n:1},
	       dataType:"html"
	    }).done(function(e){
	       var r = $.parseJSON(e);
		   var h = $('<thead></thead>').html('<tr><td>#</td><td>Contestant</td><td>Score</td></tr>');
		   var t = $('<table></table>', {class:"normal box"}).css({"margin":0}).append(h);
		   var b = $('<tbody></tbody>');
		   var n = 1;
		   $.each(r, function(i,d){
				var tr = $('<tr></tr>');
				var t1 = $('<td></td>', {class:"tac"}).html('<span>'+n+'</span>');
				var t2 = $('<td></td>').html(d['name']);
				var t3 = $('<td></td>', {class:"text-blue tac"}).html((d['score']%1==0)? d['score'] : d['score'].toFixed(2));
				$(tr).append(t1).append(t2).append(t3).appendTo(b);
				n++;
		   });
		   $(t).append(b);
		   function load(obj, tbl, cid){
				var ax = obj.attr('ax');
				var cn = obj.attr('cn');
				var ac = obj.attr('ac');
				$.ajax({
				   url:BASEURL + "ajax.php?q=" + ax,
				   type:"POST",
				   data:{d:cid, n:1},
				   dataType:"html"
				}).done(function(e){
					tbl.find('tbody').remove();
	       			var r = $.parseJSON(e);
					var n = 1;
					var b = $('<tbody></tbody>');
					$.each(r, function(i,d){
						var tr = $('<tr></tr>');
						var t1 = $('<td></td>', {class:"tac"}).html('<span>'+n+'</span>');
						var t2 = $('<td></td>').html(d['name']);
						var t3 = $('<td></td>', {class:"text-blue tac"}).html((d['score']%1==0)? d['score'] : d['score'].toFixed(2));
						$(tr).append(t1).append(t2).append(t3).appendTo(b);
						n++;
				   });
				   tbl.append(b);
				});
		   }
		   popup_box({title:"Ranking based on "+cn, content:t, height:200},{ submit:true, name:"print", id:"print", class:"btn-primary", value:"Print", close:"Close"});
		   var data = setInterval(function(){ 
				var div = $("div#xxx");
				if(div.length==0)  clearInterval(data);
				else load(vr, t, ac);
		   }, 5000);
		   $("#print").click(function(){
				$.ajax({
				   url:BASEURL + "ajax.php?q=" + ax.replace('vr','prc'),
				   type:"POST",
				   data:{d:ac,n:1},
				   dataType:"html"
				}).done(function(e){
					var r = $.parseJSON(e);
					var s = $('<span></span>').addClass('pointer').html('<i class="icon-download"></i> '+r['file']);
					$(s).click(function(){ window.location = r['path'] + r['file']; }).attr('data-placement', 'right').attr('data-original-title', 'Click to Download').tooltip();
					popup_box({title:"Download", content:s, class:"bart"});
				});
		   });
	    });
   });
   $("#pre").click(function(){
		$.ajax({
		   url:BASEURL + "ajax.php?q=" + $(this).attr('ax'),
		   type:"POST",
		   data:{d:$(this).attr('ae'),n:1},
		   dataType:"html"
		}).done(function(e){
			var r = $.parseJSON(e);
			var s = $('<span></span>').addClass('pointer').html('<i class="icon-download"></i> '+r['file']);
			$(s).click(function(){ window.location = r['path'] + r['file']; }).attr('data-placement','right').attr('data-original-title','Click to Download').tooltip();
			popup_box({title:"Download", content:s, class:"dogz"});
		});
   });
   function setDash(obj){
		$.ajax({
           url:BASEURL + "ajax.php?q=" + obj.attr('ax'),
           type:"POST",
           data:{ d:obj.val(), n:1},
           dataType:"html"
        }).done(function(e){ return e; }).fail(function(jqXHR, textStatus){ popup_box({content:"setDash(): " + textStatus}); });
   }
   function setPhoto(obj){
   		$.ajax({
           url:BASEURL + "ajax.php?q=" + obj.attr('ax'),
           type:"POST",
           data:{ d : 0 },
           dataType:"html"
        }).done(function(e){
		   var r = $.parseJSON(e);
           obj.attr('src', BASEURL + 'upl/' + r['photo']);
		   $("div.box.ac").addClass('pointer').attr('data-placement', 'bottom').attr('data-original-title', r['address']).tooltip();
        }).fail(function(jqXHR, textStatus) {
           popup_box({content:"setPhoto(): " + textStatus});
        });
   }
   function setJudge(){
		var div = $("div.judges");
   		$.ajax({
           url:BASEURL + "ajax.php?q=" +  div.attr('ax'),
           type:"POST",
           data:{ d : 0 },
           dataType:"html"
        }).done(function(e){
		   var r = $.parseJSON(e);
		   div.find('div.content').empty();
		   $.each(r, function(i,d){
				var sp = $('<span class="label label-soft-gray"></span>').css({"margin-right":"5px"});
				if(d['score']){
					$(sp).html('<i class="icon-ok-circle"></i> '+d['name']);
				} else {
					$(sp).html('<i class="icon-time"></i> '+d['name']);
				}
				div.find('div.content').append(sp.addClass('pointer').attr('data-placement', 'top').attr('data-original-title', d['description']).tooltip());
		   });
        });
   }
   function setRank(){
		var tbl = $("table.cool").addClass('pointer').attr('data-placement','top').attr('data-original-title','Ranking based on Score').tooltip();
		$.ajax({
           url:BASEURL + "ajax.php?q=" + tbl.attr('ax'),
           type:"POST",
           data:{d:1},
           dataType:"html"
        }).done(function(e){
		   var n = 1;
		   var r = $.parseJSON(e);
		   tbl.find('tbody').remove();
		   $.each(r, function(i,d){
				var d1 = $('<td></td>', {class:"tac"}).html('<span>'+n+'</span>');
				var d2 = $('<td></td>').html(d['name']);
				var d3 = $('<td></td>', {class:"text-blue tac"}).html((d['score']%1==0)? d['score'] : d['score'].toFixed(2));
				var tr = $('<tr></tr>').append(d1).append(d2).append(d3);
				var tb = $('<tbody></tbody>').append(tr);
				tbl.append(tb);
				n++;
		   });
        });
   }
   function setProgress(){
		$("div.progress-bar").find('div.content').find('img').remove();
		var divTotal = $("div.progress.total").css({"margin":"2px"});
		var divBreak = $("div.progress.break").css({"margin":"10px 2px 2px 2px"});
		var cntBreak = divBreak.find('div');
		$.ajax({
           url:BASEURL + "ajax.php?q=" + divTotal.attr('ax'),
           type:"POST",
           data:{d:1},
           dataType:"html"
        }).done(function(e){
			var r = $.parseJSON(e);
			var w = r['progress']+"%";
			divTotal.find('div.bar').addClass('pointer').attr('data-placement','top').attr('data-original-title',r['criteria']).css({"width":w}).tooltip().find('span').html(w);
			divTotal.fadeIn();
		});
		if(cntBreak.length==0){
			$.ajax({
		       url:BASEURL + "ajax.php?q=" + divBreak.attr('ax'),
		       type:"POST",
		       data:{d:1},
		       dataType:"html"
		    }).done(function(e){
				var r = $.parseJSON(e);
				$.each(r, function(i,d){
					var w = d['percentage']+"%";
					var s = $('<span></span>').html(w);
					var d = $('<div></div>', {class:d['class'], "data-placement":"top", "data-original-title":d['criteria']}).css({"width":w}).append(s).tooltip();
					divBreak.append(d.addClass('pointer'));
				});
				divBreak.fadeIn();
			});
		}
   }
});
</script>
