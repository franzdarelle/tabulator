<?php 
   $form = new HTML_Form;
   $crit = new CRITERIAS;
   $arg4 = arg(4);
   $link = MAIN_CLASS.'/admin/criteria/'.$arg4;
?>
<div class="container bg">
   <div class="row">
      <div class="span3"><?php print getViewsContents('side'); ?></div>
      <div class="span9">
         <div class="pagetitle">
            <h2>Criteria</h2>
            <p>Some description about this page</p>
         </div>
         <div id="main-content">
            <?php
               if(isset($_SESSION[$crit->message])){ 
                  print messageBox($_SESSION[$crit->message]); 
                  unset($_SESSION[$crit->message]); 
               }
            ?>
            <div class="box">
               <div class="header">
                  <h4><span class="icon_application-form"></span>List</h4>
                  <div class="box-control pull-right">
                     <a class="btn dropdown-toggle" data-toggle="dropdown" href="#" data-original-title="Actions"><i class="icon-cog"></i></a>
                     <ul class="dropdown-menu">
                        <li id="add"><a href="#" data-original-title="Add Criteria"><i class="icon-plus"></i>Add</a></li>
                        <li id="ups" ca="checkbox-uniform" ax="criteria/get"><a href="#" data-original-title="Edit Criteria"><i class="icon-edit"></i>Edit</a></li>
                        <li id="del" ca="checkbox-uniform" ax="criteria/del" hl="<?php echo $link; ?>"><a href="#" data-original-title="Delete Criteria"><i class="icon-remove"></i>Delete</a></li>
                        <li id="all" ca="checkbox-uniform"><a href="#" data-original-title="Check All"><i class="icon-list"></i><span class="all">Check All</span></a></li>
                        <li id="ref"><a href="#" data-original-title="Refresh"><i class="icon-refresh"></i>Refresh</a></li>
                     </ul>
                  </div>
               </div>
               <div class="content" id="nopad">
                  <table class="normal bt-dataTable" border="0" cellpadding="0" cellspacing="0" width="100%" id="dataTable">
                     <thead>
                        <tr>
                           <th class="chk">&nbsp;</th>
                           <th>Criteria</th>
                           <th>Percentage</th>
						   <th>Event</th>
						   <th>Status</th>
                        </tr>
                     </thead>
                     <tbody>
                     <?php foreach ($crit->setEID($arg4)->get('x') as $d): ?>
                        <tr class="gradeX">
                           <td class="tal">
                              <label class="checkbox inline">
                                 <input type="checkbox" class="checkbox-uniform" value="<?php print $d['id']; ?>">
                              </label>
                           </td>
                           <td><?php print stripslashes($d['criteria']); ?></td>
                           <td><?php print stripslashes($d['percentage']); ?></td>
						   <td><?php print stripslashes($d['event']); ?></td>
						   <td><?php print ($d['status']==0)? '<span class="label">Inactive</span>' : '<span class="label label-success"><i class="icon-ok"></i>Active</span>'; ?></td>
                        </tr>
                     <?php endforeach; ?>
                     </tbody>
                  </table>
               </div>
            </div>
            <div class="clear"></div>
         </div>
      </div>
   </div>
</div>
<div class="add">
<?php 
   $rand = random_string(5);
   $attr = array(
               'name' => 'add_criteria',
               'class' => 'form-horizontal system',
               'location' => $link,
               'filter' => $rand
   );
   $addform = $form->startForm("criteria/add", "post", "add_criteria", $attr).$form->endForm(); 
?>
   <input class="input-large <?php echo $rand; ?>" type="hidden" name="e" value="<?php echo $arg4; ?>"/>
   <div class="rowelement pop">
      <div class="span3"> Criteria: </div>
      <div class="span3"><input class="input-large <?php echo $rand; ?>" type="text" name="c"/></div>
      <div class="clear"></div>
   </div>
   <div class="rowelement pop">
      <div class="span3"> Percentage: </div>
      <div class="span3"><input class="input-large <?php echo $rand; ?> tar" type="text" name="p"/></div>
      <div class="clear"></div>
   </div>
</div>
<div class="ups">
<?php 
   $rand = random_string(5);
   $attr = array(
               'name' => 'ups_criteria',
               'class' => 'form-horizontal system',
               'location' => $link,
               'filter' => $rand
   );
   $upsform = $form->startForm("criteria/ups", "post", "ups_criteria", $attr).$form->endForm(); 
?>
   <input class="input-large <?php echo $rand; ?>" type="hidden" name="id"/>
   <input class="input-large <?php echo $rand; ?>" type="hidden" name="eid"/>
   <div class="rowelement pop">
      <div class="span3"> Criteria: </div>
      <div class="span3"><input class="input-large <?php echo $rand; ?>" type="text" name="criteria"/></div>
      <div class="clear"></div>
   </div>
   <div class="rowelement pop">
      <div class="span3"> Percentage: </div>
      <div class="span3"><input class="input-large <?php echo $rand; ?>" type="text" name="percentage"/></div>
      <div class="clear"></div>
   </div>
</div>
<script type="text/javascript">
$(document).ready(function(){
   $(".tar").filter_input({regex:'[0-9]'});
   $("#ref").click(function(){ Redirect('<?php echo $link; ?>'); })
   $("div.checker").css({"margin-left":0,"margin-right":0, "padding":0});
   $('.pop').css({"padding":0});
   $(".add, .ups").css({"overflow":"hidden"});
   $("#add").add('<?php print $addform; ?>', 'Add Criteria', $("div.add"), 300, true, 'bart', true, 'save', 'save', 'btn btn-primary', 'Save', 'Cancel');
   $('#ups').ups('<?php print $upsform; ?>', 'Edit Criteria', $("div.ups"), 300, true, 'dogz',true, 'save', 'save', 'btn btn-primary', 'Save', 'Cancel');
   $('#all').all($('span.all'));
   $('#del').del();
});
</script>
