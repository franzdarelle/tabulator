<?php 
	$user = new USERS; 
	$dash = new DASH;
	$data = $dash->getDash();
?>
<div class="navbar navbar-fixed-top">
	<div class="navbar-inner">
		<div class="container">
		   <div id="header">
		      <div id="logo"></div>
		      <div id="info">
		         <ul id="userBox">
		            <li class="dropdown">
		               <a class="dropdown-toggle" data-toggle="dropdown" href="#"><span class="icon-acc"></span><span class="fit"><b class="caret"></b></span></a>
		               <ul class="dropdown-menu">
		               <?php if($user->session->getType()==1): ?>
		                  <li><a href="<?php echo generateUrl(str_replace('user', 'admin', PAGE_DASH)); ?>"><span class="icon_dash"></span>Dashboard</a></li>
						  <li><a href="<?php echo generateUrl(MAIN_CLASS.'/admin/criteria/'.$data['event']); ?>"><span class="icon_document-list"></span>Criterias</a></li>
					   <?php else: ?>
						  <li><a href="<?php echo generateUrl(PAGE_DASH); ?>"><span class="icon_dash"></span>Dashboard</a></li>
						  <li><a href="<?php echo generateUrl(str_replace('dashboard', 'contestant', PAGE_DASH).'/'.$data['contestant']); ?>"><span class="icon_users"></span>Contestant</a></li>
		               <?php endif; ?>
		               </ul>
		            </li>
		            <li class="dropdown">
		               <a class="dropdown-toggle" data-toggle="dropdown" href="#"><span><?php echo ucwords($user->session->getUser()); ?></span><span class="fit"><b class="caret"></b></span></a>
		               <ul class="dropdown-menu">
		                  <li><a href="<?php echo $user->session->getLink(); ?>"><span class="icon-acc"></span>Account Settings</a></li>
		                  <li><a href="<?php echo generateUrl(PAGE_HALT); ?>"><span class="icon-off"></span>Sign Out</a></li>
		               </ul>
		            </li>
		         </ul>
		      </div>
		      <div class="clear"></div>
		   </div>
		</div>
	</div>
</div>
