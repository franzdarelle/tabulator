<?php 
  $user = new USERS; 
  $arg3 = arg(3);
?>
<div class="sidebar">
    <ul class="side-nav sliding_menu collapsible">
    <?php 
		if($user->session->getType()==1): 
			$http = MAIN_CLASS.'/admin/';
	?>
       <li><a class="nobordertop <?php if($arg3=='dashboard') echo 'current'; ?>" href="<?php print generateUrl($http.'dashboard'); ?>"><span class="icon_dash"></span>Dashboard</a></li>
       <li><a class="<?php if($arg3=='event') echo 'current'; ?>" href="<?php print generateUrl($http.'event'); ?>"><span class="icon_stats"></span>Event</a></li>
       <li><a class="<?php if($arg3=='contestant') echo 'current'; ?>" href="<?php print generateUrl($http.'contestant'); ?>"><span class="icon_users"></span>Contestant</a></li>
       <li><a class="<?php if($arg3=='judge') echo 'current'; ?>" href="<?php print generateUrl($http.'judge'); ?>"><span class="icon_users"></span>Judge</a></li>
       <!--<li><a href="messages.html"><span class="icon_balloon-buzz"></span>Messages <span class="label label-info">5</span></a></li>-->
	<?php 
		else: 
			$http = MAIN_CLASS.'/user/';
			$dash = new DASH;
			$juds = new JUDGES;
			$arg4 = arg(4);
	?>
	<li><a class="nobordertop <?php if($arg3=='dashboard') echo 'current'; ?>" href="<?php print generateUrl($http.'dashboard'); ?>"><span class="icon_dash"></span>Dashboard</a></li>
	<?php if($juds->eid($user->session->getUid())==$dash->db['event']): ?>
	<li><a class="<?php if($arg3=='contestant') echo 'current'; ?>" href="#"><span class="icon_users"></span>Contestant</a>
		<ul class="acitem">
		<?php 
			foreach($dash->getContestants() as $c): 
				$class = (empty($arg4))? (($c['status'])? (($c['id']==$dash->db['contestant'])? "icon-play-circle" : "icon-ok-circle") : "icon-time") : 
				(($arg4==$c['id'])? "icon-play-circle" : "icon-time");
		?>
        	<li>
				<a href="<?php print generateUrl($http.'contestant/'.$c['id']); ?>">
					<span class="sidenav-icon"><span class="sidenav-link-color"></span><i class="identifier <?php echo $class; ?>"></i></span>
					<?php echo $c['number'].' - '.stripslashes($c['name']); ?>
				</a>
			</li>
		<?php endforeach; ?>
        </ul>
    </li>
	<?php endif; ?>
    <?php endif; ?>
    </ul>
 </div>
