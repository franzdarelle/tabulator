<?php
$class = random_string(5);
$token = random_string(30);
$field = array(
	'name' => random_string(5),
	'pass' => random_string(5)
);
?>
<div class="container-fluid">
	<div class="row-fluid">
		<div id="main-content" class="login-content">
			<!--<div id="login_logo"></div>-->
			<?php 
				$form = new HTML_Form; 
				$attr = array(
								'name' => 'login_form',
								'class' => 'form-signin',
								'location' => MAIN_CLASS . '/user/dashboard'
				);
				print $form->startForm("user/signin", "post", "validation", $attr); 
			?>
				<p>Username:</p>
				<div class="input-prepend">
					<span class="add-on">
						<span class="icon-user"></span>
					</span>
					<input type="text" name="<?php echo $field['name']; ?>" class="span11 validate[required] <?php echo $class; ?>" placeholder="Username">
				</div>
				<p>Password:</p>
				<div class="input-prepend">
					<span class="add-on">
						<span class="icon-lock"></span>
					</span>
					<input type="password" name="<?php echo $field['pass']; ?>" class="span11 validate[required] <?php echo $class; ?>" placeholder="Password">
				</div>
				<label class="checkbox inline pull-left"><input type="checkbox" class="checkbox-uniform" value="remember-me">Remember me</label>
				<button class="btn btn-primary pull-right" type="submit" id="sign" filter="<?php echo $class; ?>" token="<?php echo $token; ?>" target=".form-signin">Sign in</button>
				<div class="clear"></div>
			<?php print $form->endForm(); ?>
		</div>
	</div>
</div>	
<script type="text/javascript">
$('#sign').click(function(){
	if(filterInput($(this).attr('filter'))){
		$('<input type="hidden" name="token" value="'+$(this).attr('token')+'">').appendTo($($(this).attr('target')));
		return true;
	}
	return false;
});
$("form").live("submit", function() {
	var formname = $(this).attr("name");
	var action	 = $(this).attr("action");
	var targetloc= $(this).attr("location");
	var method	 = $(this).attr("method") ? $(this).attr("method") : "GET";
	var formdata = $(this).serialize();
	submitKeys = $("form[name="+formname+"] .formactions").html();
	$.ajax({
		url : BASEURL + "ajax.php?q=" + action,
		type: method,
		cache:true,
		data: { d:formdata },
		mimeType:"multipart/form-data",
		dataType:"html"
	}).done(function(e) {
		if(!isNaN(e)) {
			$(location).attr("href", BASEURL+((FREEURL)? "":"?q=")+targetloc);
		} else {
			popup_box({content:e});
			$("form[name="+formname+"] .formactions").html(submitKeys);
		}
	}).fail(function(jqXHR, textStatus) {
		popup_box({content:"Request failed: "+textStatus});
	});
	return false;
});
</script>
<?php 
	$_SESSION['token'] = $token; 
	$_SESSION['field'] = $field;
	$token = $field = null;
?>
