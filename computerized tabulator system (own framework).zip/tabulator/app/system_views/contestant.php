<?php 
   $form = new HTML_Form;
   $cont = new CONTESTANTS; 
   $link = MAIN_CLASS.'/admin/contestant';
?>
<div class="container bg">
   <div class="row">
      <div class="span3"><?php print getViewsContents('side'); ?></div>
      <div class="span9">
         <div class="pagetitle">
            <h2>Contestant</h2>
            <p>Some description about this page</p>
         </div>
         <div id="main-content">
            <?php 
               if(isset($_SESSION[$cont->message])){ 
                  print messageBox($_SESSION[$cont->message]); 
                  unset($_SESSION[$cont->message]); 
               }
            ?>
            <div class="box">
               <div class="header">
                  <h4><span class="icon_application-form"></span>List</h4>
                  <div class="box-control pull-right">
                     <a class="btn dropdown-toggle" data-toggle="dropdown" href="#" data-original-title="Actions"><i class="icon-cog"></i></a>
                     <ul class="dropdown-menu">
                        <li id="add"><a href="#" data-original-title="Add Contestant"><i class="icon-plus"></i>Add</a></li>
                        <li id="ups" ca="checkbox-uniform" ax="contestant/get"><a href="#" data-original-title="Edit Contestant"><i class="icon-edit"></i>Edit</a></li>
                        <li id="del" ca="checkbox-uniform" ax="contestant/del" hl="<?php echo $link; ?>"><a href="#" data-original-title="Delete Contestant"><i class="icon-remove"></i>Delete</a></li>
                        <li id="all" ca="checkbox-uniform"><a href="#" data-original-title="Check All"><i class="icon-list"></i><span class="all">Check All</span></a></li>
                        <li id="ref"><a href="#" data-original-title="Refresh"><i class="icon-refresh"></i>Refresh</a></li>
                     </ul>
                  </div>
               </div>
               <div class="content" id="nopad">
                  <table class="normal bt-dataTable" border="0" cellpadding="0" cellspacing="0" width="100%" id="dataTable">
                     <thead>
                        <tr>
                           <th class="chk">&nbsp;</th>
                           <th style="width:50px">#</th>
                           <th>Name</th>
                           <th>Address</th>
                           <th>Status</th>
                           <th>Event</th>
                        </tr>
                     </thead>
                     <tbody>
                     <?php foreach ($cont->get('a') as $d): $name = stripslashes($d['name']); ?>
                        <tr class="gradeX">
                           <td class="tal">
                              <label class="checkbox inline">
                                 <input type="checkbox" class="checkbox-uniform" value="<?php print $d['id']; ?>">
                              </label>
                           </td>
                           <td class="tal"><?php print $d['number']; ?></td>
                           <td class="nml" src="<?php echo BASEURL; ?>upl/<?php print $d['photo']; ?>" alt="<?php print $name; ?>" str="<?php echo random_string(5); ?>">
								<span><?php print $name; ?></span>
						   </td>
                           <td><?php print stripslashes($d['address']); ?></td>
                           <td><?php if($d['status']==0): ?><span class="label"><i class="icon-lock"></i> Inactive</span>
						   <?php else: if($d['eliminate']){ $s='label-important'; $i='icon-ban-circle'; $t='Inactive'; } else { $s='label-success'; $i='icon-ok'; $t='Active'; } ?>
						   <span class="label <?php print $s; ?>"><i class="<?php print $i; ?>"></i> <?php echo $t; ?></span><?php $s = $i = $t = null; endif; ?></td>
                           <td><?php print stripslashes($d['event']); ?></td>
                        </tr>
                     <?php endforeach; ?>
                     </tbody>
                  </table>
               </div>
            </div>
            <div class="clear"></div>
         </div>
      </div>
   </div>
</div>
<div class="upl">
<?php $uplform = $form->startForm(BASEURL."ajax.php?q=contestant/upl", "post", "if1", array('enctype' => 'multipart/form-data')).$form->endForm(); ?>
   <div id='ils' style='display:none'><img src="<?php echo BASEURL; ?>img/loader.gif" alt="Uploading...."/></div>
   <div id='ilb'><input type="file" name="photos[]" id="file" multiple="true" class="input-medium"/></div>
</div>
<div class="upe">
<?php $upeform = $form->startForm(BASEURL."ajax.php?q=contestant/upl", "post", "if2", array('enctype' => 'multipart/form-data')).$form->endForm(); ?>
   <div id='ilse' style='display:none'><img src="<?php echo BASEURL; ?>img/loader.gif" alt="Uploading...."/></div>
   <div id='ilbe'><input type="file" name="photos[]" id="filee" multiple="true" class="input-medium"/></div>
</div>
<div class="add">
<?php 
   $rand = random_string(5);
   $attr = array(
               'name' => 'add_contestant',
               'class' => 'form-horizontal system',
               'location' => $link,
               'filter' => $rand
   );
   $addform = $form->startForm("contestant/add", "post", "add_contestant", $attr).$form->endForm(); 
?>
   <div class="rowelement pop">
      <div class="span3"> Event: </div>
      <div class="span3">
         <select class="input-large <?php echo $rand; ?>" name="evnt"/>
            <?php foreach ($cont->get('e') as $d): ?>
            <option value="<?php echo $d['id']; ?>"><?php echo stripslashes($d['name']); ?></option>
            <?php endforeach; ?>
         </select>
      </div>
      <div class="clear"></div>
   </div>
   <div class="rowelement pop">
      <div class="span3"> Number: </div>
      <div class="span3"><input class="input-large tar <?php echo $rand; ?>" type="text" name="numb"/></div>
      <div class="clear"></div>
   </div>
   <div class="rowelement pop">
      <div class="span3"> Name: </div>
      <div class="span3"><input class="input-large <?php echo $rand; ?>" type="text" name="name"/></div>
      <div class="clear"></div>
   </div>
   <div class="rowelement pop">
      <div class="span3"> Address: </div>
      <div class="span3"><textarea class="input-large <?php echo $rand; ?>" name="addr"></textarea></div>
      <div class="clear"></div>
   </div>
   <div class="rowelement pop">
      <div class="span3"> Photo: </div>
      <div class="span3" id="uip"><input type="button" class="btn" id="uit" value="Upload"></div>
      <div class="clear"></div>
   </div>
</div>
<div class="ups">
<?php 
   $rand = random_string(5);
   $attr = array(
               'name' => 'ups_contestant',
               'class' => 'form-horizontal system',
               'location' => $link,
               'filter' => $rand
   );
   $upsform = $form->startForm("contestant/ups", "post", "ups_contestant", $attr).$form->endForm(); 
?>
   <input class="input-large <?php echo $rand; ?>" type="hidden" name="id"/>
   <div class="rowelement pop">
      <div class="span3"> Event: </div>
      <div class="span3">
         <select class="input-large <?php echo $rand; ?>" name="event"/>
            <?php foreach ($cont->get('e') as $d): ?>
            <option value="<?php echo $d['id']; ?>"><?php echo stripslashes($d['name']); ?></option>
            <?php endforeach; ?>
         </select>
      </div>
      <div class="clear"></div>
   </div>
   <div class="rowelement pop">
      <div class="span3"> Number: </div>
      <div class="span3"><input class="input-large tar <?php echo $rand; ?>" type="text" name="number"/></div>
      <div class="clear"></div>
   </div>
   <div class="rowelement pop">
      <div class="span3"> Name: </div>
      <div class="span3"><input class="input-large <?php echo $rand; ?>" type="text" name="name"/></div>
      <div class="clear"></div>
   </div>
   <div class="rowelement pop">
      <div class="span3"> Address: </div>
      <div class="span3"><textarea class="input-large <?php echo $rand; ?>" name="address"></textarea></div>
      <div class="clear"></div>
   </div>
   <div class="rowelement pop">
      <div class="span3"> Photo: </div>

      <div class="span3" id="uipe"><input type="button" class="btn" id="uie" value="Change"></div>
      <div class="clear"></div>
   </div>
</div>
<?php generate_javascripts(array(BASEURL.'js/jquery.wallform.js')); ?>
<script type="text/javascript">
$(document).ready(function(){
   $("#ref").click(function(){ Redirect('<?php echo $link; ?>'); });
   $(".tar").filter_input({regex:'[0-9]'});
   $("div.checker").css({"margin-left":0, "margin-right":0, "padding":0});
   $(".nml").click(function(){
      var image = $('<img src="'+$(this).attr('src')+'">').css({"margin":0,"padding":0,"width":"100%"}); 
      popup_box({title:$(this).attr('alt'),content:image, class:$(this).attr('str')});
   }).find('span').css({"cursor":"pointer"}).attr('data-placement','right').attr('data-original-title', 'View Image').tooltip();
   $('.pop').css({"padding":0});
   $(".add, .upl, .ups").css({"overflow":"hidden"});
   $("#add").add('<?php print $addform; ?>', 'Add Contestant', $("div.add"), 400, true, 'bart', 
	function(){
		var reset = setInterval(function(){
			var div = $("div#bart");
			if(div.length==0){
				$.ajax({
				   url:BASEURL + "ajax.php?q=contestant/reset",
				   type:"POST",
				   data:{ d : 0 },
				   dataType:"html"
				}).done(function(e){
					if(e) clearInterval(reset);
				});
			}
		}, 1000);
	}, 'save', 'save', 'btn btn-primary', 'Save', 'Cancel');
   $("#uit").add('<?php print $uplform; ?>', 'Upload Photo', $("div.upl"), 300, true, 'papz', false, false, false, false, false, false);
   $("#uie").css({"margin-left":5}).add('<?php print $upeform; ?>', 'Upload Photo', $("div.upe"), 300, true, 'papz', false, false, false, false, false, false);
   $('#ups').ups('<?php print $upsform; ?>', 'Edit Contestant', $("div.ups"), 400, true, 'dogz', 
      function(obj){
         var div = $("div.ups");
         div.find('select').each(function(){
            $(this).find('option').each(function(){
               if($(this).attr('value')==obj['eid']) $(this).attr('selected', 'selected');
            });
         });
         div.find('textarea').each(function(){
            $(this).html(obj[$(this).attr('name')]);
         });
         $('.img').remove();
         $('#uipe').prepend('<img src="'+BASEURL+'upl/'+obj['photo']+'" class="img">');
		 var reset = setInterval(function(){
			var div = $("div#dogz");
			if(div.length==0){
				$.ajax({
				   url:BASEURL + "ajax.php?q=contestant/reset",
				   type:"POST",
				   data:{ d : 0 },
				   dataType:"html"
				}).done(function(e){
					if(e) clearInterval(reset);
				});
			}
		 }, 1000);
         return true;
      }, 'save', 'save', 'btn btn-primary', 'Save', 'Cancel');
   $('#all').all($('span.all'));
   $('#del').del();
   $('#file').die('click').live('change', function(){ 
      $("#if1").ajaxForm({target: '#uip', 
          beforeSubmit:function(){ 
            console.log('ttest');
            $("#ils").show();
            $("#ilb").hide();
            $("#uip").html('');
         }, 
         success:function(){ 
            console.log('test');
            $("#ils").hide();
            $("#ilb").show();
         }, 
         error:function(){ 
            console.log('xtest');
            $("#ils").hide();
            $("#ilb").show();
         } 
      }).submit();
   });
   $('#filee').customFileInput({button_position:'right'}).die('click').live('change', function(){ 
      $("#if2").ajaxForm({target: '#uipe', 
          beforeSubmit:function(){ 
            console.log('ttest');
            $("#ilse").show();
            $("#ilbe").hide();
            $("#uipe").html('');
         }, 
         success:function(){ 
            console.log('test');
            $("#ilse").hide();
            $("#ilbe").show();
         }, 
         error:function(){ 
            console.log('xtest');
            $("#ilse").hide();
            $("#ilbe").show();
         } 
      }).submit();
   });
});
</script>
