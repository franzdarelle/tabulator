<?php 
   $user = new USERS;
   $form = new HTML_Form;
   $link = (FREEURL)? str_replace(BASEURL, '', $user->session->getLink()) : str_replace(BASEURL.'?q=', '', $user->session->getLink());
?>
<div class="container bg">
   <div class="row">
      <div class="span3"><?php print getViewsContents('side'); ?></div>
      <div class="span9">
         <div class="pagetitle">
            <h2>Account</h2>
            <p>Some description about this page</p>
         </div>
         <div id="main-content">
            <?php 
               if(isset($_SESSION[$user->message])){ 
                  print messageBox($_SESSION[$user->message]); 
                  unset($_SESSION[$user->message]); 
               }
            ?>
            <div class="box">
               <div class="header">
                  <h4><span class="icon_application-form"></span>Information</h4>
                  <div class="box-control pull-right">
                     <a class="btn dropdown-toggle" data-toggle="dropdown" href="#" data-original-title="Options"><i class="icon-cog"></i></a>
                     <ul class="dropdown-menu">
                        <li id="usr"><a href="#" data-original-title="Change Username"><i class="icon-edit"></i>Username</a></li>
                        <li id="pwd"><a href="#" data-original-title="Change Password"><i class="icon-edit"></i>Password</a></li>
                     </ul>
                  </div>
               </div>
               <div class="content">
                  <div class="rowelement">
                     <div class="span3"> Username: </div>
                     <div class="span5"><span class="input-xlarge uneditable-input"><?php echo $user->session->getUser(); ?></span></div>
                     <div class="clear"></div>
                  </div>
                  <div class="separator"></div>
                  <div class="rowelement">
                     <div class="span3"> Password: </div>
                     <div class="span5"><span class="input-xlarge uneditable-input"><?php foreach(range(0, strlen($user->getContent($user->getShadow($user->session->getUid()).'.txt')) - 1) as $i) echo '*'; ?></span></div>
                     <div class="clear"></div>
                  </div>
               </div>
            </div>
            <div class="clear"></div>
         </div>
      </div>
   </div>
</div>
<div class="usr">
<?php 
   $rand = random_string(5);
   $attr = array(
               'name' => 'usr_form',
               'class' => 'form-horizontal system',
               'location' => $link,
               'filter' => $rand
   );
   $userform = $form->startForm("user/changeusr", "post", "usr_form", $attr).$form->endForm(); 
?>
   <div class="rowelement pop">
      <div class="span3"> Username: </div>
      <div class="span3"><input class="input-large <?php echo $rand; ?>" type="text" name="uname"/></div>
      <div class="clear"></div>
   </div>
   <div class="rowelement pop">
      <div class="span3"> Password: </div>
      <div class="span3"><input class="input-large <?php echo $rand; ?>" type="password" name="upass"/></div>
      <div class="clear"></div>
   </div>
</div>
<div class="pwd">
<?php 
   $rand = random_string(5);
   $attr = array(
               'name' => 'pwd_form',
               'class' => 'form-horizontal system',
               'location' => $link,
               'filter' => $rand
   );
   $passform = $form->startForm("user/changepwd", "post", "pwd_form", $attr).$form->endForm(); 
?>
   <div class="rowelement pop">
      <div class="span3"> Old Password: </div>
      <div class="span3"><input class="input-large <?php echo $rand; ?>" type="password" name="opass"/></div>
      <div class="clear"></div>
   </div>
   <div class="rowelement pop">
      <div class="span3"> New Password: </div>
      <div class="span3"><input class="input-large <?php echo $rand; ?>" type="password" name="npass"/></div>
      <div class="clear"></div>
   </div>
   <div class="rowelement pop">
      <div class="span3"> Confirm Password: </div>
      <div class="span3"><input class="input-large <?php echo $rand; ?>" type="password" name="cpass"/></div>
      <div class="clear"></div>
   </div>
</div>
<script type="text/javascript">
$(document).ready(function(){
   $('.pop').css({"padding":0});
   $(".pwd, .usr").css({"overflow":"hidden"});
   $("#usr").add('<?php print $userform; ?>', 'Change Username', $("div.usr"), 300, true, 'bart', true, 'save', 'save', 'btn btn-primary', 'Save', 'Cancel');
   $("#pwd").add('<?php print $passform; ?>', 'Change Password', $("div.pwd"), 300, true, 'dogz', true, 'save', 'save', 'btn btn-primary', 'Save', 'Cancel');
});
</script>
