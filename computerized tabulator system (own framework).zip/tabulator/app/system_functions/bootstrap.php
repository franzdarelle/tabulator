<?php
# BASE URL
function baseURL() {
	$currentFile = $_SERVER["PHP_SELF"]; 
	$urlParts = explode('/', $currentFile); 
	unset($urlParts[count($urlParts) - 1]); 
	return implode('/', $urlParts) . '/';
}

# Genarate URL
function generateUrl($request){
	return (FREEURL)? (baseURL().$request) : ((empty($request))? baseURL() : (baseURL().'?q='.$request));
}

# GET
function request_GET() {
	$get = (isset($_GET))? $_GET : false;
	return $get;
}

# POST
function request_POST() {
	$post = (isset($_POST))? $_POST : false;
	return $post;
}

# GET SERIALIZED FORM
function get_serialized_form($value) {
	
	if(is_array($value))
		return false;
	else {
		$perfs = explode("&", $value);
		foreach($perfs as $perf) {
			$perf_key_values = explode("=", $perf);
			$key = urldecode($perf_key_values[0]);
			$values = urldecode(@$perf_key_values[1]);
			if(getLast2chars($key)=="[]") {
				$key = str_replace("[]","",$key);
				$data[$key][] = $values;
			} else {
				$data[$key] = $values;
			}
		}
	}
	
	return $data;
}

# GET LAST 2 CHARS
function getLast2chars($string) {
	$keyword_length = strlen($string);
	return substr($string, $keyword_length-2, 2);
}

# PAGE HANDLER
function page_handler() {
	$ret = array();
	$get = request_GET();
	if(empty($get)) header('Location: ' . generateUrl(PAGE_HOME));
	else {
		$req = isset($get['q'])? explode("/", $get['q']) : explode("/", PAGE_HOME); 
		$mod = new Page($req);
		$ret['title']	= $mod->getTitle();
		$ret['menu']	= $mod->getMenu();
		$ret['content']	= $mod->getContent();
		return $ret;
	}
}

function ajax_handler() {
	$post= request_POST();
	$get = request_GET();
	if(isset($get)) { 
		$request = $get['q']; 
		$exp_req = explode("/", $request);		
		if(file_exists(SITE_ROOT . CLASS_PATH . "ajax." . $exp_req[0] . ".class" . EXT)) {
			$parameter 	= get_serialized_form(@$post['d']);
			$module = new PageAjax($request, $parameter);
			print $module->getContent();
		}
	}
}
