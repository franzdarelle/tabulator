<?php
# INCLUDE MODEL FILES 
function insertModel($name) {
	if(!class_exists($name)) include SITE_ROOT . MODEL_PATH . $name . EXT;
}

# INCLUDE VIEWS FILES 
function insertView($name) {
	include SITE_ROOT . VIEW_PATH . $name . EXT;
}

# GET VIEWS CONTENTS 
function getViewsContents($name=null) {
	ob_start();
	if(is_array($name)) {
		foreach($name as $view)
			insertView($view);
	} else 
		insertView($name);
	
	$contents = ob_get_contents();
	ob_end_clean();
	return $contents;
}

# ADD ATTRIBUTES
function addAttributes( $attr_ar ) {
    $str = '';
        $min_atts = array('checked', 'disabled', 'readonly', 'multiple');
		if(!empty($attr_ar) && is_array($attr_ar)){
			foreach( $attr_ar as $key=>$val ) {
				if ( in_array($key, $min_atts) ) {
					if ( !empty($val) ) { 
						$str .= " $key=\"$key\"";
					}
				} else {
					$str .= " $key=\"$val\"";
				}
			}
		}
    return $str;
}
 
# OTHER FUNCTIONS
function selfURL() {
	$pageURL = 'http';
	if (isset($_SERVER["HTTPS"]) AND $_SERVER["HTTPS"] == "on") $pageURL .= "s";
	$pageURL .= "://";
	if ($_SERVER["SERVER_PORT"] != "80") 
		$pageURL .= $_SERVER["SERVER_NAME"].":".$_SERVER["SERVER_PORT"].$_SERVER["REQUEST_URI"];
	else
		$pageURL .= $_SERVER["SERVER_NAME"].$_SERVER["REQUEST_URI"];

	return $pageURL;
}

# Get arguments from queue/q the requested q from the URL.
# eg. ?q=brandon/clients/page/3 => arg(3)=page, arg(1)=brandon, arg(5)=null
function arg($argument=null) {
	$queue = isset($_GET['q']) ? $_GET['q'] : array();
	$args  = explode("/", $queue);
	$argument--;
	return isset($args[$argument])? $args[$argument] : null;
}

function random_string($chars=5) {
	$string = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
	$result = substr( str_shuffle( $string ), 0, $chars );
	return $result;
}

# RANDOM COLOR BUILDER
function getRandomColor($length = 6) {
	  $validCharacters = "abcdefABCDEF1234567890";
	  $validCharNumber = strlen($validCharacters);

	  $result = "";
	  for ($i = 0; $i < $length; $i++) {
		  $index = mt_rand(0, $validCharNumber - 1);
		  $result .= $validCharacters[$index];
	  }
	  return "#".$result;
}
 
function removeQueryStringVar($url, $key) { 
  $url = preg_replace('/(.*)(?|&)' . $key . '=[^&]+?(&)(.*)/i', '$1$2$4', $url . '&'); 
  $url = substr($url, 0, -1); 
  return $url; 
}

function changeQueryStringVar($var, $val) { 
	parse_str($_SERVER['QUERY_STRING'], $qs);
	$qs[$var] = $val;
	return http_build_query($qs); 
}

function header_scripts() {
	$script = "";
	$script .= "<script type='text/javascript'>";
	$script .= "var BASEURL='".BASEURL."';";
	$script .= "var FREEURL=".FREEURL.";";
	$script .= "refresh_session(BASEURL);";
	$script .= "</script>\n";
	return $script;
}

function generate_javascripts($sources=array()) {
	$scripts = '';
	foreach($sources as $script) {
		$scripts .= '<script type="text/javascript" src="' . $script . '"></script>'."\n";
	}
	print $scripts;
}

function generate_stylesheets($sources=array()) {
	$styles = '';
	foreach($sources as $style) {
		$styles .= '<link rel="stylesheet" media="screen" type="text/css" href="'. $style .'"/>'."\n";
	}
	print $styles;
}

# FUNCTIONS -------------------

function getPageVar($var='page') {
	return (isset($_GET[$var]) AND $_GET[$var]>=1)? $_GET[$var] : 1;
}

function getUIPagingParams(&$totalRecord, &$displayingItems, &$page, &$queryString, $pageVar='page', $naviVar=array()) {
		
		$navigator		= '';
		$queryString 	= removeQueryStringVar($queryString, $pageVar);
		if(!empty($naviVar)){
			foreach($naviVar as $key=>$val){
				$queryString 	= removeQueryStringVar($queryString, $key);
				$navigator		.= (!empty($key) && !empty($val))? '&' . $key . '=' . $val : '';
			}
		}
		$r['page']		= ($page=="" OR $page<1)? 1 : $page;
		$r['from']		= ($r['page'] * $displayingItems) - $displayingItems;
		$r['items'] 	= $displayingItems;
		$r['paging']	= pagingUI($r['items'], $totalRecord, $r['page'], '?' . $queryString . '&' . $pageVar . '=', $navigator);
		
		return $r;
}

function pagingUI($max_record, $total, $current, $link="", $navigator) {
	
	if($total<1) return;

	$pages		= '<ul class="pager-bart">';
	$no_of_pages 	= ceil($total / $max_record);
	$page_anchor 	= 0;

	if($no_of_pages == 1) return false;
	$current = ($current <= 0) ? 1 : (($current>$no_of_pages) ? $no_of_pages : $current);
	
	if( $current != 1 ) { //DISPLAY PREVIOUS & FIRST anchor if current page is not the first page
		$pages .= "<li class='pager-bart-first'><a href='".$link."1".$navigator."'>&laquo;First</a></li>";
		$pages .= "<li class='pager-bart-previous'><a href='".$link."".($current - 1).$navigator."'>&lsaquo;Prev</a></li>";
	}
				
	$page_anchor= ( $current > 5 ) ? $current-5 : $page_anchor;
	$page_limit = ($no_of_pages < $current + 4) ? $no_of_pages : $current + 4;
		
	while($page_anchor != $page_limit) {
		$page_anchor++;
		$currentClass = ($page_anchor == $current)? "current" : "";
		$pages .= "<li class='pager-bart-item'><a href='".$link.$page_anchor.$navigator."' class='$currentClass' id='page-anchor'>$page_anchor</a></li>";
	}
	
	if( $no_of_pages != $current ) { //DISPLAY NEXT & LAST anchor if current page is not the last
		$pages .= "<li class='pager-bart-next'><a href='".$link."".($current + 1).$navigator."'>Next&rsaquo;</a></li>";
		$pages .= "<li class='pager-bart-last'><a href='".$link."".$no_of_pages.$navigator."'>Last&raquo;</a></li>";
	}

	return '<center>'.$pages.'</center>';
}
// END PAGINATION


# converting array to object
function arrayToObject($d) {
	if (is_array($d)) {
		/*
		* Return array converted to object
		* Using __FUNCTION__ (Magic constant)
		* for recursive call
		*/
		return (object) array_map(__FUNCTION__, $d);
	}
	else {
		// Return object
		return $d;
	}
}

# convertion object to array
function objectToArray($d) {
	if (is_object($d)) {
		// Gets the properties of the given object
		// with get_object_vars function
		$d = get_object_vars($d);
	}

	if (is_array($d)) {
		/*
		* Return array converted to object
		* Using __FUNCTION__ (Magic constant)
		* for recursive call
		*/
		return array_map(__FUNCTION__, $d);
	}
	else {
		// Return array
		return $d;
	}
}

function messageBox($text, $type='alert-success', $icon='icon_success') {
	$output = '<div class="alert '.$type.'">';
	$output .= '<button class="close" data-dismiss="alert" type="button" data-original-title="">×</button>';
	$output .= '<span class="'.$icon.'"></span>'.$text;
	$output .= '</div>';
	return $output;
}

function error404() {	
	$output = '<div class="container white"><div class="box nobot">';
	$output .= '<div class="header"><h4><span class="icon-warning-sign"></span>Page Not Found</h4><div class="box-control pull-right"><a class="btn" data-original-title="Close" href="'.generateUrl(PAGE_HOME).'"><i class="icon-remove"></i></a></div></div>';
	$output .= '<div class="content pad"><div class="rowelement">';
	$output .= "The requested page '<em>".$_SERVER['REQUEST_URI']."</em>' could not be found.";
	$output .= '</div></div></div><div class="clear"></div></div>';
	return $output;
}
