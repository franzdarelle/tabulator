<?php 
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);
define('SITE_ROOT', getcwd());
require_once SITE_ROOT . '/web/settings.php';
$page = page_handler();
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html;charset=utf-8">
	<meta name="<?php echo WEB_ALIAS; ?>" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="<?php echo WEB_DESCRIPTION; ?>">
	<meta name="author" content="<?php echo WEB_AUTHOR; ?>">
	<title><?php print $page['title']; ?></title>
	<?php generate_stylesheets($stylesheets); ?>
	<!--[if lt IE 9]><link href="css/ie-hacks.css" rel="stylesheet" media="screen"><![endif]-->
	<link rel="shortcut icon" href="<?php echo BASEURL; ?>ico/favicon.ico">
	<?php generate_javascripts(array(BASEURL.'js/jquery.js',BASEURL.'js/kevin.js')); ?>
	<?php print header_scripts(); ?>
</head>
<body>
<?php print $page['menu']; ?>
<div id="main"><?php print $page['content']; ?></div>
<?php generate_javascripts($javascripts); ?>
<!--[if lt IE 9]>
<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->
<!--[if lt IE 9]>
<script src="http://css3-mediaqueries-js.googlecode.com/svn/trunk/css3-mediaqueries.js"></script>
<![endif]-->
</body>
</html>
