<?php
#SYSTEM
	date_default_timezone_set('Asia/Manila');
	define('MAIN_CLASS', 'tab');
	define('DB_KEYWORD', 'tab');
	define('WEB_TITLE', 'TABULATOR');
	define('WEB_ALIAS',	'TABZ');
	define('WEB_AUTHOR','TABZ');
	define('WEB_DESCRIPTION', "TABULATOR");
	define('WEB_SESSION', 'bartz');
	define('MIN_SCORE', 50);
	define('MAX_SCORE', 100);
#PAGES
	define('PAGE_HOME', MAIN_CLASS . '/user/signin');
	define('PAGE_HALT', MAIN_CLASS . '/user/signout');
	define('PAGE_DASH', MAIN_CLASS . '/user/dashboard');
#DATABASE
	define("DB_HOST", 'localhost');
	define("DB_USER", 'root');
	define("DB_PASS", '');
	define("DB_NAME", 'curve');
#PATHS,IMAGES,SALTS
	define('SALT_LENGTH', 10);
	define('CLASS_PATH', '/app/system_classes/');
	define('MODEL_PATH', '/app/system_models/');
	define('VIEW_PATH',	 '/app/system_views/');
	define('IMG_UPLOAD', 'IMG_UPLOAD');
	define('MAX_UPLOAD', 500);
	define('IMG_SIZE_W', 225);
	define('IMG_SIZE_H', 225);
	define("EXT", '.php');
#CLASSES,FUNCTIONS
include_once SITE_ROOT . '/app/system_classes_loader.php';
$folder = array('system_functions','system_classes','system_models');
$loader = new LOADER;
$loader->load($folder);
#STYLESHEETS,JAVASCRIPTS
define('FREEURL', 1);
define('BASEURL', baseURL());
$stylesheets = array(
	BASEURL.'css/bootstrap.css',
	BASEURL.'css/bootstrap-responsive.css',
	BASEURL.'css/bootstrap-formhelpers.css',
	BASEURL.'css/style.css',
	BASEURL.'css/prettify.css',
	BASEURL.'css/smoothness/jquery-ui-1.8.16.custom.css',
	BASEURL.'css/datatable/datatable_custom.css',
	BASEURL.'css/fullcalendar.css',
	BASEURL.'css/elfinder.css',
	BASEURL.'css/flot/jquery.flot_custom.css',
	BASEURL.'css/validationEngine.css',
	BASEURL.'js/jQuery-UI-FileInput/css/enhanced.css',
	BASEURL.'css/fancybox/jquery.fancybox.css',
	BASEURL.'css/kevin.css'
);
$javascripts = array( 
	BASEURL.'js/charts/flot/jquery.flot.js',
	BASEURL.'js/charts/flot/jquery.flot.pie.js',
	BASEURL.'js/charts/flot/jquery.flot.symbol.js',
	BASEURL.'js/charts/flot/jquery.flot.axislabels.js',
	BASEURL.'js/charts/flot/jquery.flot.resize.js',
	BASEURL.'js/charts/jquery.sparkline.min.js',
	BASEURL.'js/jquery.nicescroll.min.js',
	BASEURL.'js/jquery.autogrowtextarea.min.js',
	BASEURL.'js/jquery.dataTables.min.js',
	BASEURL.'js/dataTable_bootstrap.js',
	BASEURL.'js/fullcalendar.js',
	BASEURL.'js/elfinder.min.js',
	BASEURL.'js/jquery-ui-1.8.16.custom.min.js',
	BASEURL.'js/jquery.fancybox.pack.js',
	BASEURL.'js/jQuery-UI-FileInput/js/enhance.min.js',
	BASEURL.'js/jQuery-UI-FileInput/js/fileinput.jquery.js',
	BASEURL.'js/jQuery-validation/jquery.validationEngine.js',
	BASEURL.'js/jQuery-validation/languages/jquery.validationEngine-en.js',
	BASEURL.'js/inputmask.jquery.js',
	BASEURL.'js/uniform.jquery.js',
	BASEURL.'js/chosen.jquery.js',
	BASEURL.'js/bootstrap-timepicker.js',
	BASEURL.'js/jquery.tagsinput.js',
	BASEURL.'js/jquery.cleditor.min.js',
	BASEURL.'js/bootstrap.js',
	BASEURL.'js/prettify.js',
	BASEURL.'js/accordion.jquery.js',
	BASEURL.'js/ios-orientationchange-fix.js',
	BASEURL.'js/custom.js',
	BASEURL.'js/charts-custom.js'
);
